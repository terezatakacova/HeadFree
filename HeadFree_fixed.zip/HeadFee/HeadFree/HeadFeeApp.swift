//
//  HeadFeeApp.swift
//  HeadFee
//
//  Created by Tereza Takacova on 03/10/2026.
//

import SwiftUI

@main
struct HeadFeeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
