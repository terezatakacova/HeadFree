import SwiftUI

@main
struct HeadFreeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
