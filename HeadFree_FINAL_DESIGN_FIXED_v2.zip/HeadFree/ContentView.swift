import SwiftUI
import Foundation
import UserNotifications
import UIKit

// MARK: - APP

struct ContentView: View {
    @AppStorage("headFreeIntroSeen") private var introSeen = false

    var body: some View {
        Group {
            if introSeen {
                HeadFreeHomeView()
            } else {
                HFIntroView {
                    introSeen = true
                }
            }
        }
        .onAppear {
            HeadFreeNotificationDelegate.shared.start()
        }
    }
}

// MARK: - NOTIFICATIONS

final class HeadFreeNotificationDelegate: NSObject, UNUserNotificationCenterDelegate {

    static let shared = HeadFreeNotificationDelegate()

    private override init() {
        super.init()
    }

    func start() {
        let center = UNUserNotificationCenter.current()
        center.delegate = self

        center.getNotificationSettings { settings in
            if settings.authorizationStatus == .notDetermined {
                center.requestAuthorization(
                    options: [.alert, .sound, .badge]
                ) { _, _ in }
            }
        }
    }

    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification,
        withCompletionHandler completionHandler:
            @escaping (UNNotificationPresentationOptions) -> Void
    ) {
        completionHandler([.banner, .sound, .badge])
    }
}

private func reminderID(
    _ task: String,
    _ scope: String
) -> String {
    "HeadFree.\(scope).\(Data(task.utf8).base64EncodedString())"
}

private func scheduleReminder(
    task: String,
    date: Date,
    scope: String
) {
    guard date > Date() else {
        return
    }

    let center = UNUserNotificationCenter.current()

    center.getNotificationSettings { settings in

        let authorized =
            settings.authorizationStatus == .authorized ||
            settings.authorizationStatus == .provisional ||
            settings.authorizationStatus == .ephemeral

        guard authorized else {
            return
        }

        let content = UNMutableNotificationContent()
        content.title = "HeadFree"
        content.body = task
        content.sound = .default

        let parts = Calendar.current.dateComponents(
            [.year, .month, .day, .hour, .minute],
            from: date
        )

        let trigger = UNCalendarNotificationTrigger(
            dateMatching: parts,
            repeats: false
        )

        let request = UNNotificationRequest(
            identifier: reminderID(task, scope),
            content: content,
            trigger: trigger
        )

        center.add(request)
    }
}

private func cancelReminder(
    task: String,
    scope: String
) {
    UNUserNotificationCenter.current()
        .removePendingNotificationRequests(
            withIdentifiers: [
                reminderID(task, scope)
            ]
        )
}

private func loadReminderData(
    _ key: String
) -> [String: Date] {

    guard
        let data =
            UserDefaults.standard
                .string(forKey: key)?
                .data(using: .utf8),
        let value =
            try? JSONDecoder()
                .decode(
                    [String: Date].self,
                    from: data
                )
    else {
        return [:]
    }

    return value
}

private func saveReminderData(
    _ value: [String: Date],
    key: String
) {
    guard
        let data =
            try? JSONEncoder().encode(value),
        let string =
            String(
                data: data,
                encoding: .utf8
            )
    else {
        return
    }

    UserDefaults.standard.set(
        string,
        forKey: key
    )
}

// MARK: - INTRO

struct HFIntroView: View {
    let onContinue: () -> Void

    private let cream = Color(red: 0.955, green: 0.935, blue: 0.885)
    private let olive = Color(red: 0.430, green: 0.510, blue: 0.355)
    private let text = Color(red: 0.245, green: 0.255, blue: 0.225)

    var body: some View {
        GeometryReader { geo in
            ZStack {
                cream.ignoresSafeArea()

                if let data = Data(base64Encoded: hfReferenceBranchBase64),
                   let uiImage = UIImage(data: data) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFit()
                        .frame(width: min(235, geo.size.width * 0.48),
                               height: min(430, geo.size.height * 0.52))
                        .opacity(0.82)
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
                        .padding(.leading, -8)
                        .padding(.top, 34)
                }

                VStack(spacing: 0) {
                    Spacer()
                    Text("HeadFree")
                        .font(.system(size: 42, weight: .regular, design: .serif))
                        .foregroundStyle(text)
                        .padding(.bottom, 18)

                    Button(action: onContinue) {
                        Text("Pokračovať")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundStyle(.white)
                            .frame(width: min(250, geo.size.width * 0.68), height: 54)
                            .background(olive, in: Capsule())
                    }
                    .buttonStyle(.plain)
                    .padding(.bottom, max(28, geo.safeAreaInsets.bottom + 20))
                }
            }
        }
        .ignoresSafeArea()
    }
}

struct HeadFreeHomeView: View {

    var body: some View {

        NavigationStack {

            ZStack {

                hfBackground
                    .ignoresSafeArea()

                ScrollView(
                    showsIndicators: false
                ) {

                    VStack(spacing: 7) {

                        HStack {

                            Text("HeadFree")
                                .font(
                                    .system(
                                        size: 32,
                                        weight: .regular,
                                        design: .serif
                                    )
                                )
                                .foregroundStyle(
                                    Color(
                                        red: 0.245,
                                        green: 0.255,
                                        blue: 0.225
                                    )
                                )

                            Spacer()

                            NavigationLink {

                                HFSettingsView()

                            } label: {

                                Image(
                                    systemName:
                                        "gearshape"
                                )
                                .font(
                                    .system(
                                        size: 18,
                                        weight: .light
                                    )
                                )
                                .foregroundStyle(
                                    Color(
                                        red: 0.245,
                                        green: 0.255,
                                        blue: 0.225
                                    )
                                    .opacity(0.72)
                                )
                            }
                            .buttonStyle(.plain)
                        }
                        .padding(.horizontal, 24)
                        .padding(.top, 18)
                        .padding(.bottom, 22)

                        HFHomeCard(
                            title: "Dnes",
                            icon: "checkmark",
                            color: Color(
                                red: 0.875,
                                green: 0.845,
                                blue: 0.730
                            ),
                            scope: "today"
                        ) {
                            TodayView()
                        }

                        HFHomeCard(
                            title: "Tento týždeň",
                            icon: "calendar",
                            color: Color(
                                red: 0.820,
                                green: 0.855,
                                blue: 0.765
                            ),
                            scope: "week"
                        ) {
                            WeekView()
                        }

                        HFHomeCard(
                            title: "Tento mesiac",
                            icon: "calendar",
                            color: Color(
                                red: 0.885,
                                green: 0.805,
                                blue: 0.690
                            ),
                            scope: "month"
                        ) {
                            MonthView()
                        }

                        HFHomeCard(
                            title: "Nápady",
                            icon: "lightbulb",
                            color: Color(
                                red: 0.900,
                                green: 0.830,
                                blue: 0.755
                            ),
                            scope: "ideas"
                        ) {
                            IdeasView()
                        }

                        HFHomeCard(
                            title: "Nákupy",
                            icon: "cart",
                            color: Color(
                                red: 0.790,
                                green: 0.850,
                                blue: 0.750
                            ),
                            scope: "shopping"
                        ) {
                            ShoppingView()
                        }

                        HFHomeCard(
                            title: "Plánované výdavky",
                            icon: "eurosign",
                            color: Color(
                                red: 0.850,
                                green: 0.820,
                                blue: 0.735
                            ),
                            scope: "expenses"
                        ) {
                            ExpensesView()
                        }

                        HFHomeCard(
                            title: "Pripomienky",
                            icon: "bell",
                            color: Color(
                                red: 0.875,
                                green: 0.835,
                                blue: 0.770
                            ),
                            scope: "reminders"
                        ) {
                            HFRemindersView()
                        }
                    }
                    .padding(.horizontal, 18)
                    .padding(.bottom, 24)
                }
            }
            .toolbar(
                .hidden,
                for: .navigationBar
            )
        }
    }
}

struct HFHomeCard<Destination: View>: View {

    let title: String
    let icon: String
    let color: Color
    let scope: String
    let destination: () -> Destination

    private var count: Int {

        switch scope {

        case "today":
            return storedArray(
                "todayTasks"
            ).count

        case "week":
            return storedArray(
                "weekTasks"
            ).count

        case "month":
            return storedArray(
                "monthTasks"
            ).count

        case "ideas":
            return storedArray(
                "ideas"
            ).count

        case "shopping":
            return storedArray(
                "shoppingItems"
            ).count

        case "expenses":
            return storedArray(
                "plannedExpenses"
            ).count

        case "reminders":

            return
                loadReminderData(
                    "todayTaskReminders"
                ).count
                +
                loadReminderData(
                    "weekTaskReminders"
                ).count
                +
                loadReminderData(
                    "monthTaskReminders"
                ).count

        default:
            return 0
        }
    }

    var body: some View {

        NavigationLink {

            destination()

        } label: {

            HStack(spacing: 12) {

                Image(
                    systemName: icon
                )
                .font(
                    .system(
                        size: 15,
                        weight: .light
                    )
                )
                .frame(width: 22)
                .foregroundStyle(
                    Color(
                        red: 0.245,
                        green: 0.255,
                        blue: 0.225
                    )
                    .opacity(0.72)
                )

                Text(title)
                    .font(
                        .system(
                            size: 15.5,
                            weight: .regular
                        )
                    )
                    .foregroundStyle(
                        Color(
                            red: 0.245,
                            green: 0.255,
                            blue: 0.225
                        )
                    )

                Spacer()

                if count > 0 {

                    Text("\(count)")
                        .font(
                            .system(
                                size: 12,
                                weight: .regular
                            )
                        )
                        .foregroundStyle(
                            Color(
                                red: 0.245,
                                green: 0.255,
                                blue: 0.225
                            )
                            .opacity(0.48)
                        )
                }
            }
            .padding(.horizontal, 16)
            .frame(
                maxWidth: .infinity
            )
            .frame(height: 56)
            .background(
                color.opacity(0.88)
            )
            .clipShape(
                RoundedRectangle(
                    cornerRadius: 13,
                    style: .continuous
                )
            )
        }
        .buttonStyle(.plain)
    }
}

private func storedArray(
    _ key: String
) -> [String] {

    guard
        let value =
            UserDefaults.standard.string(
                forKey: key
            ),
        !value.isEmpty
    else {
        return []
    }

    return value.components(
        separatedBy: "|||"
    )
}

// MARK: - TASK LISTS

enum HFTaskScope {
    case today
    case week
    case month

    var title: String {
        switch self {
        case .today: return "Dnes"
        case .week: return "Tento týždeň"
        case .month: return "Tento mesiac"
        }
    }

    var tasksKey: String {
        switch self {
        case .today: return "todayTasks"
        case .week: return "weekTasks"
        case .month: return "monthTasks"
        }
    }

    var completedKey: String {
        switch self {
        case .today: return "completedTodayTasks"
        case .week: return "completedWeekTasks"
        case .month: return "completedMonthTasks"
        }
    }

    var reminderKey: String {
        switch self {
        case .today: return "todayTaskReminders"
        case .week: return "weekTaskReminders"
        case .month: return "monthTaskReminders"
        }
    }

    var notificationScope: String {
        switch self {
        case .today: return "today"
        case .week: return "week"
        case .month: return "month"
        }
    }
}

// MARK: - EXACT HEADFREE INNER STYLE

private let hfBackground = Color(red: 0.900, green: 0.850, blue: 0.755)
private let hfText = Color(red: 0.205, green: 0.215, blue: 0.185)
private let hfMuted = Color(red: 0.470, green: 0.465, blue: 0.405)
private let hfLine = Color(red: 0.815, green: 0.765, blue: 0.665)
private let hfGreen = Color(red: 0.430, green: 0.510, blue: 0.355)
private let hfGreenLight = Color(red: 0.700, green: 0.750, blue: 0.615)
private let hfGold = Color(red: 0.760, green: 0.650, blue: 0.430)


// MARK: - REFERENCE BOTANICAL BRANCH

private let hfReferenceBranchBase64 = """
iVBORw0KGgoAAAANSUhEUgAAAK8AAAEYCAYAAAAqKqYMAACvTUlEQVR4nNz9W7BlSXoehn1/Zq7LvpxLnVNVp6p6ume6Z3qIHs4QA2BADTgwQBEIwbw4GISDDNMmpbAsWw5H0OEwLUXowX6z/aInh8PyiymFbF1M2pQok7IpEhIIDUhAMwRAzXAa6B50N6u7q7su574v65KZvx8yc61ca6+9zz51mwazomLvs/ZauXLl+vPP77/T8vLTXcFQ2NAsQW/6vd9CfwYMACCileuZWUnQdbpduf6pL/YtHhcR6X6f4bk33av/bERkojHKTfe/6hmedn5Cv2H8/TFuet/MrMJ1V93/KrpgiKX7YnaiwydEFH4P94QQAoIYxhiUywUuzk6xvLxAXRUQUiJJEiRJBindlEopNxPt82rMrAZessYVi2ZTf0PHhxbJpvOve8666+L7XkWwz3q/bVo7Hr5yDIPvxV8XxrhuXq9szCkD9ulZ1ObWWaHrVmQ4ftVKu4qDP492XcJ9pnts2ecQEWzsd8t23R3vae4zNPbV982D87vpfTdcH569xv02O3Izhg6PZ9686EJ7KZz3OoQ1NPHh+ufNra7q71mI4EVw1j4n3PYe8diYWfEVsGGbe1/VBEMZwGw6p0ukFgAh4vpX3mMQ471oDjrU/6YXse22Hyb2WZ9jiONtIsznyfXXtfieT7MwnnV+43Of5nmJSBPWEaUFs4AEwTKDGKAtmO8L57wv48W+7BaEu03P9iww4mXN2ZCQuk3bhoCZWYGoDPfZql9Y/80CZDeeC1xBvH0OdF2tBF1DWt40kVcJYq1UPYwRr3pJT4Mt4z6vggvrxt8/Hq59WsjxNHBiqI/tBVwaODZ87vAc2HBP/999710LeExsrYYQgBDuNi8F827bnpYThLZukl6kZP+8+v+s9PGjuO96fLuZ+3Zu+qPAus/SWFDRn7jrYLKnleZDC/chy/nG867oh5lV/xwi0uYKVdfzbpagiaC3veu2RCsYnecT3Nyv0/pc199lbb+fKc4LXJ/7Dp3fbr+bn+9Faweetv3zKCdc851udZ4CruaI4fc+ofQnOWjnnzfH2MRNf5REF+blqqfdZvxPK8U/S1uRUQJmJljy5q9tdLlbN2JvUltPnNsSLhApkK+8b9giX8IEE5HedB+nq3T/n+U+1+nnKv3n014f2lWquJdN2EywL8PoNHjvbY0UDfd4RlNgZ8KvqaW4bv/PilWf9XrBcER/zeuurU8VVMTH+tqEpxVw1+mxmZyERCD7fHY0m21zVkys4fu1jRTr2vPYsp/ZTv4Zalepw140lOmr6V7E/YghXpRlc6g5Yr2eF4Rq8OkGO/YKho0sWEMP2HAmzzkMGCDocLzp5gpCftEc9ro7gmGTEZFhP27BIiJYALB5fF+ynMfPGI9nnU9BZxFsGMsQ0a57HqdFuHpxBZzrb7DWcSr0JdH1Quv/zhw87OxVkAlEBMPOTMEEQBCY2RO1+y+otRwQ0faY9w96exqcTAwRXujTcJ/nYYF7Htg+9LXp3p8lbQswDBv68OKpB0xEBtHEboIFT7O1MbMKK+tZOfBQ30DrNbKWAw/sKsws22e0Xr8ritWL426CsHu1f/A62WFofred1+b5OtyeVnbUbS2GYdewa3TC7TW00TFn+0YYghRPxXljh+tnac8qwb/o9ry43vNsz+oUdB3NyvNy5nlRTQlGB7O8CIHqqkm4aqX3OePz5sTbt3WL1m60sDUcLWh2nlEb87yE3033JQDmqnl+yQTc1wGvcN4tV+ZW0QLbtueJ7da1q170toTwWdSWPG/u+1l4xj6hDhkvOha2fszWxhim56Ccf1pVTBjXdS15fQ7fYNHo96GxrOP0JLqeI2y3g2EvW/k/NM+fhW3/uo2BNvwCT4l5t77ZNfXAfe77o+DEf5A58FD7gzDObS1qoQUuvFlPOMBxriKopzFc+AFtjF4YvO45Yd8+Zw1TKcCpH8nKuIjICKISsLkA2bquD4VKHjOzZNt1DBry22VmKYQon2Xcnd2jjVQYdFJad33/ufr9Xue61XNYXyXcxxY1IhqwsHX80QCI5tzP9NbxWbPKdWGHzYw1u3VdH1ptduq6PszHox8mSfbxNiqs56mxeWFC9hbM4XnqjFc5cBcY9HHv2pW3zc36A1/Bhs9p21/3gvpY/UWZSptxQCxBNnPPxUrX9eF8fvn15WLxh+q6Ptzjg7+3syMKKZNjY+2YhbwAWi3Dtu262pRWtXVNrUXPd2Lbzfs6i2WTcL8OLoTjbYTFsOw1uG1/ltwPr9q++t5uzyMaY/P9/HeYcV2X9xbL2VcvLy7+haqqjkiIZZIkx+OxKIUQxbo4gM/KTvIi2jqjBgAQXREacXXfnb+fSWOwgq+eeljDbduX3PfUX2c5uzLDS+95bCd0u7WiMbNisDTGTLTWe3VdHxZF8dp8cfn10Wj0Xpqmj7JsdGyNTeL7Pu/MRFe15+E99zLvt02LMfGV2obPikol+LSu2yG2sQptapuvWzX/hvOtNROAJcCyLMt7s/nFN5bL5RvG1IefRQvd82qfhd1jI/F+liZ+G0NG+E1w66cct3XHr9BFmyBcrSwgsmksVBpjJovF4s35fP5WURSvXfshP4MtOCfRFowO6M7RVULpOiy7KZoixsHNgD5LhPoy29VaAVGEF+HUUXLREDCLylqbW2tzIjLMNq+q6mi5nL+1XC5fJ7bj+B6fBW513RYc1DnCq305I7TAGGIGQfR8YteGBLeNWDZIo8+LsPvYry9cbZ0nwsdCNVs3qAr9XXdMQwJe5Hnlf2PHQZhTh7lYCVKXLOS5UNmHJJevkzUjYpdWoCoXf2h2STZN8w/TJPtEJfISzCkT6U1GS8G0FUZ/WRa65n2h6/8iNtCDYCg/D6rx4yXS0TtrhSNPkExYCWsLhBo+++6QflyID64ouF+o6uk59/20491G0zLUBKkLKeVMkLpoxgAzNrq6U1XlveVy/lZVl3et7Tru/EHb5bYVxNbCixB4iS53va5lrd824r91Kzy84Ov6FmwbpRz7WAwSE/tcQCE/UG/VPs02/bRcW0o5l1LOHYzglIi0YZtUVXV7Nrv4BiAKIUSRpukjIUSzk3Xux8O5jX5UAZBXtXXaEx5QhVmCbnYUT8QtAXt9bshNds1cqE8tmb8s/PYy73XdRkRGKXUupZwDpAFOhRAlMytjzGS5XL4hhDoXwj1HlmUPwrN4nOwdgxzs+eetbcOxuQn12b4N+jYMnLRW4c9RpMO69jSWIiLS2+ZDCG3tDnGdmw+0dmfp2ugD0Ukp5y3xBv8CuQCZMVtWxtYHRbH4MpGDM0IAaZo+JHLnB47L6C3QNr/BVkr9KI9ubx6edQY2w5uQ8Uas0VoFi1/r4wHbxbz981ciOzYS9qATx7ahJs/THLtJT/tZ4L7swn86qh8hRBGIVwhREjMLIQpjTdAySK31XlEUrwWIQURaKTJCiCLu87PwjC+6bUsr23DjKx1ztrnZNv4QzyNPLnWk3ZebFLs/j8FMTERaCFFKKWcOz7KGoAoWIMHO7Zhsqk11qyhIE8m5tTbLc1Zpmj4UJBcdAoZNt3F0afXMjSC0Zj6ejrEETmqvynTnWzhvHQfeeCcAwZApgMH8vOsIedB39iou8M8Dh7gOp3M6XJZ9TmmtzYPjicO6tlHS+wsNwIoZqHV5l4qwU4mSiHSWyoXva4Wrx+N8lrH/KFuL6V3jxsV0tTFzC9K2xMEdx5wYNlyFd+PBXe370Ojs1p5/FQTZ9oVdgyA35l3rNps5GaHrfyuJOI428Vx4bq06s9ZmFB0HgLp2JmP3PGbCzCpJkuMkSY7dMYj+3PbfyzbPdt0mqcXWPSY26BEWWxw7evoep171dnP3iXW4Q0RKRBBCNL+HzA3ht3D8Sqfiq9rVFqrV5BXrCPV5EfDLaswsPfddeT4iUp6jNuZStmSttXlVVbedAKfOgYboZ1dBhvj5PXR5Ji+tp2lXmXx757rn6TKJ695v7W9X+glsalsRLtqMLcQY5HRDHNBpM/w2E0vd7HKErSNiZlZNbNmW0vrTtr6/RUyoQojCGDPxZ7rfBTSzHWtdHVmr99w59SFgsyzLHijliJnZL2LuESexaLZecpzafX86VVvAqMws1lgar4qC2E4A85baSI/viJID991wLVYNGyuqsnWccJvBPWtba6KlMLlPF+X8Mpq1LplcRLhGCFFaawNWVtbazG+DHg/blJn0cjl/KxB4+C2o3V52e9nzyVfkJtuQBbVpz2T+vY4e191no+NFQ8CRTd1zmc16z0jP6TAag4jIPHt0aYPZV30uCEJHnDcQbkTEikgU7nfXR9BQhLFaa8ZVVbzmnFdsxswqz/P7UibHfgFkwNWEtU7K31ZbsLbfbShoQ7PUhz1QV8EGGnDAaa/vxrtdW1X2LNx4vQPM5vY0+mQnbFzpkvdMOwszS2M4YFtD5My/ATZY2xV4AoG7sbkATGYzLsvyniNyx6nznEyapg8BNFx9aO6umpNY4LoOVn1ebY2mJDI+dfFCTLSbCLiBDUPSbJ8D9i5feenr8Gu/9W3i/XNflCf+0y6afhOMDjF6d8gsVpk5F8pmPk1sfFkdRxifGVdVddtaQGu9a4yHGkqdtMSOpi9JxFsQrkIUCdKOj8z19bGDfftn+NEJ0IMqmGhru3aHz9Pq9jzaNnrSp+TsylqbG2Mm1toMLNYKTcGrjMhZ5WIOHKCGtWZclss3Aga2Vu/t7N34lUB019HDX6GxkaBtSvRt1/eL0AA5YW51ffXVaqp/84hTSDGw1cSqrzgPbecc/7mOk67LzN0os9nnuY0wGwNmQ1nEQX1kyAs89Fu3Ztu688i/HGdUsN4HgRnKGDuxgKmMnlprcyHB7SJw8xm8yJrnI1GEvkK/0e+GhFXW6r3lcv6Vqio+r7Xe29nZ+e08z+9by2nQM/df4jpiFevmhTnoaU3v/A7FWOKV48PqOfYWOaf1aMcjvJbBTjv3WVMNKB5JjH2ZCczt3wYMxprte+jBftQt2j6fR1/PRZ/NMGPmjrbAxFw8eJgRUcM9mbnDKCKoJgHAst5lY8bG0g1aOOxMRDpJkuPr7hDPmytex1D0PHffdULctW4Q6223OX/bavFAf2I85+qZE69aTX1OY6++5KlbUIEFjYAQLtw9/N4YJpxZWYVPa20enxed32DaADOWy+UbYV6m0+n3lQqLyC2KcJ+hsfW/rzlvrVl6XX/DJ9CKX7XfoQCsyjrrOW5oLXN/KiPFZ8mSFdqzct+neabVa2zm/BUcIVprc4YZE6nzPo4OY46IuOHAQ2PxnFoHq533CX5dCOe5luf5faXcfYI/8LNyuE0E3Ah53WMvx8pJdi3hDmoboh+vNThL0Mys+jUVQts2f8JVEyMcGLpS0h5q24yr39pxxlVtHCFaazNjnH9C6J9olUvFet9YbxtgxsA4g7ukAmxuTH2wWMy+RsSSeed3JpPJD5JEzr0q8Fp69nVz2yfg6Bk2c+VntGASbeuIbv1/6Sxy/uhnRisQ2jZSdV+ld1V7XpyigU3W5sbWNxpNw5o2tGV7CGH8s62osvrXEZGu6/pgPp9/RQhRKqXOgk/E82zMLHmNgDdwrhvfC44A6YeZ9fXAwebeW0HDFq11KrTrqHGA7Tgxs6vH+yzbVLMTPKP/b3938lv6lLXZEwzF/vfARNwcR7GAzlqWA8g83Ah9dp4raFnCPSyohBALa/VeURf35ELOPGwwWZZ9jCYCw2khmuDHEKEhnloj5sa9jph9/1ZcTy+/ko2TABCBLYMJ3WpAG1og4mtXwAzfnwc327CNPZcd4XmOeYB7ym10nhH27ewWw0aLVd2zEC6Ak5llVVVHi8XizaIoXov7edpnet4tPNOLHFMgXLrKPNwfWLNyeI0Tu/ce2jYrYqNS6lfhbEa6WZpuCKKXkfx5CxThhUgp58GIYIyZaq33mFm143QcOdb3xi8zhh3h7xgr97m7kFQYo3cZNhOStLH1jcVy9tUkSY6zLPs4SbIHzpHH+UUQ5NL1Y5XXaNj4vk/bVrQ2hJDHYq2lravH9gvYJ2Gx4Q3bbvSwuCKmLRwj6851nGJNPbZtcpm96PbSpNuB+2LNwok1B8256/rwrS+gxVxq3fPFRO7+dgJiWZavLBaLL+/sJCdCOKNHfJ+hcbyMORyAV36OekxpdXyd79sJcYCybMbrrMCE9SbPNYNo6nMB14g1IxaBg8UtrHixzpzLwTMfNuZuwxY8nwsiOrZufO0LGPYqI+YUxk4bbkktXo3UYZK5q1noGyTgEvSp+F1FcEDC2twVgyTNbj5gjJkU5eJLQoLzPL9PxIoofeh2RueXC6LKMivCi/JnDuNvIyqauekQ8OYqSZ0emRtnD2J0HHDWNTWkMG863LJASG8Q117lQ9gRgPdVjiMHehwmeulX3XOIOw6NdRNeCxw3EK21NmO4xc89HwSnhw0qr1bf63W0WTgHQAh50b37rGDH8K6MMZOiKF5bLBZfJiItRKtj7hB/NC/P8l7YM81tr79K/xwTZSDSIUIVPGykCNxZGW1H627yrDUT4jQ/24D4dQRm/aT1OXC/XdcrzZ0/XFfZ37xDAGE8scDWJ9o+bu10TVFIUKQyY+9rEPqL00OFBeP0v2QCjq7r+mBZzH8sSeVlkiQnUspZ2CGYu+N9XpBhta+GA69VZwLRDhd8YSLfBurFsQVCHua6Fm4dObJSmwh0hSOuOW9IleTO38pt7zPf+lJ0+3drpOg/fwQXGqgQQ4jAuYGuJqQfEzfUF+AExuVy+XqSJMeJyj5J0xRSOvw7ZPwIff0o5Ieh5ohzPbZdBxkcp3bf1SYle5iEbThaTMDN5A/c/2kINp70Z30B172/P5/WbeXxM4c5GFKPhfNinW9P6xDC6zvvZGhxhFaW5SvL5fJEyfRxFz6E67uM6XkQ7vD8D8sG/WcAWFDjKcaD9HFVi4larVulT9uuwIyDL77fXhR3eD6c3oXsxMIIs80AOe9rF+LvwRdhiBvH8CMe67qFGvyCy7K8V5blvUQVryVJcqxU+qg9XxTXDNR96sab/SM6JRfYp3vqELH7hutS89ZeX/FgBFw2xPYl2DERaRKkmWEbzBY5aDOzvApGxPcAAClETAAM9ubI8LxSHXcIskc81uq9ITVSwwX7WQ77Tj/E0vXJblqtySSRrVtCNI5LsgrRwI77dowMZXxvxyFFGdwlrWXFrPe4U5fN5pEmImvHjYYjE8m5UnJe19Xt2fzip9I0fZhlo/eEEIWUyQlbEJowqJAoxT1GYH8rC6b3HuyaqGSyTRCD8fMkwCwt+k5TPYJmskS0QqPMFszCaxtseBedT/fd+fUKETnmbMIefpDdhCRtyHSjrehtjYUQotS1mYYHJAEGr9MDRhOBVSJrVWM9M/aGLfVF42mnkrKNy2YQtBxRr0YA9xdRX7vQZlfvajSGJHd3zEwCR6+q6vZiOftqmub3iUhLmZz0hcx4DCuL9DPTWsLlLXS9V77gmGP0J8HfSNV1fRiywUgpZ0q5JBoO1VCwyoUBZqv9dCIKVsyrQd9LgrrC5SoMWQl4vOr5OtdSV3NA3oOsvyUOEJ9ysAHw6jG57t5BZea4NPZi7UKcAn8IX4d7t0xCzq21udZ6b7lcvpEmiy8rpc6TJHsghCjB3SR+z11go4FYna1auKzvtzucQWdd63K2gbZu9QNO+AhZEGez2destXmSJMd5nj5M0/SRS6LhBIkgRMS6z3YyVwm2t1gGw5H6z7l63tMJh0Pfh8YnSF24e3YXeJ+rhr78700gpD8vOOvk/eeOrxsaUwilJyJV1/VBUSzezLLs4zR1fr9SqIt1OPxH0TYs6JVjbGkjB+ZtKyZG0qJ/EehwFmPqw6JYvFmW5StSynlZ5vfzPL+fJMmxEEBIsBwgxipEEAVRnPPAufxZwEQvGcBm5fdq66sBHddfrbHMAit4Dc4WzyxB8rJznFxykHVqxkiLoLpzH8Mhh3HduTazlidEci6EKFyVIZsHbMgcEuP09c1m4ixsTnXmBbhXsqy6HScv6UGWZw+nanao/vHrC/9EDsfGQJivcCvjkLeB2aVPeprmM8EUPlncibf6vFmW5b3FYvY1R7yiCKnvhRCFkGDPsUJ2mcK/tDJsp1LaTAhRkpRNrYcYvgTiv05CbffCrvZBuLqPJuSnDAKatTyJ+1q35Q/BmhiHNtlzRLdgDJgNRWFC4fw25J6MMXrXEe/y9boevZfn+f01MK/jk/E8ufHQ/eJnvWZfnf9DbWvMO/yCXTxWnuf3d3d3vwMAl5eXX6+q4vPG1IdsbU7kvLGEEAVJsXBqHl/DwfVvAjE7Du2IQghRyDR5JIQopEhOG+IXogwcqiXi7gtZJxSuaBdgOzFyIZhy9TGb/GDNTuAX7YnzNHPeZUPb/vq5A1z2ycacDBIsiXmHbO+5Ngik7tOdb4yZ1nV9WFXVba2rI5/M2gBxspP1rZnP3rxs2xr/X4/518UQbophi4m1q2kI3h2EcJtN9ucVHBrhtY4SPkmS48lk8nbIdjibXZR1XR96VZUzdFibwWKne723CEHvB/gQczWU4hUp5SxR2SdKqQuny1Tn0r8CKZOwNZqhFbrJAPMsze0Y6txFNTjuG89T/1jc1nE7ZgY7J3USQgScHJShG/0ywm5ExMJam4WSsl5w6+h713HHIbniR9liAh4iZuDaWSID/nScyFpACNKAzaWU89Fo9J6UcialnM/nlz9RV8XnjdF71pqJl34bvWE7qaxANmUgFURaCJSAewGE5GFQG2kjyqpSt0MdCBdR0IUk4QW4MXX9hDk2BFDfIOC3615GnCFOFY4p5XYJpdR5XYsybPnOx6BbMKWjZqTWxzd4opFgyTCwxoKZISWRE2I81o3ub63NAvfvB2Eysyqr5etZlT2o69H7Wuu98Xj80AWJsmQGef3ykM+G7M8LMWf989a1oUW5HpZ0dblAa/KNf/f3Xvv9uepCw1Y6Go3eB2y+gB1pTbpx0A5D9dJ1ILpY2xBvvysBiw6mlHVdHzqVXHISoMTQpyLRn0wZhKXwt/+lownYhN1CIyLTFlRR59barO1/+NpN2Jq8g4oxBoBLriyE8C94xfo2+HeYV631ntbVbWu9s/wztm2wcX/36R8bakK4xWmtx7buL9eHYOCKPIHP9GDtqg9WJceRXKZDp8Qvy/JeVVVHLiWSczqJJluy0w377Z+lU/xLTURaERTYKrAonT+uzq0FmEibGjAyOSYiAyEWrbDnCEoIUeZp+qQRiigYSsCt1sJzPoYAtzkiVifdq/nYZ6zxR6WUsyRJjqWUs7rGbZ+TITjHXJlZPsyBH7sCAGMMrGUopeBzlTTn+c8OB/ILPHPRGM5hvdbl3aqqjnyAaHC7LBicRM/43JK4rGtX+XNrayClbLKgC1gY4/B/XdfNeUOqNMCle5K4njK/cRrvboGOo5GrTXZGRHrstBFNSnvj0G+znRpjpq4fr10IhMZt//5b3ydAAYDWeh8AmGgKsilBLqSiWtbJqRCisFrfCLAighaNLrbRObuyrB3vrW0FHEHqMmgCukLU9loMT7zwcwIibriS76f/DgAvtYTfyLkRGmut9Jj3QGu9Z4yZNEUOwUnMOLYZW3TP5+6RJqUEwNBaw9gaMBbWWljWENjkGunaU3Hexkld9KXqoLAnLQSrPB+/CwDWgMKLtJZM2AaNMVOn7qmVE/bUuRCiIKCT88qVTCDVGgOavAbOWseYADZj2KllgMnsCSFKq6vSwQuHkWNYQUSaGLLvmNchYhGk/fXeWe2C6vYRsOm667rPR5qIWAjhsS7DWtsSZm/+KXJqCecIIYKvrwxaB8cwYuK9um1acNsScPNcV4TGSylQ1zWWyyXKagkYCyHc824i2tAUEZmn1fPGD7r6UKKUknSSZA+yzBMEqtvG1gfsda5EZMLW1sIPllKIKiTe2A47Bq2CzawFXIIOMtbKWZC+A+FGnHgmSeiImA0zd3YSwnqnj8ChY24eY+mhtE4DKj3nw+DnQgihpJSwPjDRh8hj6D0OcOMmCUmscdBa74WCLf05XLeYNrV4wV1FzHxFnTljDJbLJc4vTlFVFRJBSNMUidhuU3g2MN/kqOrauNtt05U3zbLsgXfcltA29TisCRz0wo4Kn65POSe4Uk/9fltjA8uA9RycCfpJMswAsSPiuA+ipl7wLJHpscetJ76gienez6ZDKiQBuQQ7fNtqPjp5yTbCh/a4X7TUODT5rdRxXWutE9qiNRQEu5h4I07c3E9rvVdV1e26rg+zLHvQf4bBed3SI9ECBswkMEyUIX8EOxVmYw7vnEOEZbHE+fk5Tk9PYa3F7mSMPM8hJUEpgfqqGLZNP24SOoZa/OLalSnnSrFKkuxBXZupMWbCMNbl9xKllC0MiBPXAYAUzqUy1gREYwtWp0hD0PeZ6HpmBeHFc+JCy/qWUurcmOyTJJWXUiSnJFgQ5IIES7aiwrqUSkJeCFaJ8yFwXlzWIgsC2NCc+L8jAg/P2mRXh5QSzMYLbo7zBuId2kpjCBGoj5mlZb0bMG/fuT3mmkPvdx3BPWvz90SARpcXZ7i8OMNiMXMcN0mQpY7/WFuufebQFIhFU/uh3yw6jsSBw1rqWk5itutenM0cVwwmX3Wepm3RPebqyHotCAnSBPLETCHJnDN9eh/Ztt9uCzpLhhmDus7bjqOFMqqeiDwxs2UJA1S16yNR1a3UqLM0yT9MUnmpJNWtkOg0IcysLJhc/1QzqIJQJyodl0oVrymZf2jt4k1jbC6JLNz5/R0pdj5X1ppJu62CLFuvTZCNzyoRAWQb4mQG2LbCTCywtZ8MY8zEGDOp6/Ie8/R7QRPidjdnZGksin39bs9y2SfifiadPnwM1d+FoNoYMyW4+3pNEMqqQFEscH76GGcnT8DMSMcZ8iyBUgrWAGABZmp2H2r03sJb6F5CGdSWE8tZEJ5CgjpmMwGLSgjSRHLG0oyN8dzZKfEbPW+sjYg4aWyAWEnuEbchLhOwtrXLLxjrxmU5e4AMUDJ9DGZuFr6gipxDkmEi72AuSiGAJElOkiQ50VpdWNa7PKCg7BNu/zdrbQcecM+qFMOE9T4dXUxtrd4bqhMXv5fn3WIGEjkotX4ZxKiqCpeX55jPZ9C6QpIkSBIJpZSDSXYgA8lAe0HEu+pt5VVo52maPgpaBmOcQ3VjHSOwhwPaGDOxBhT0mJ6Ai1iFBLIZt0JSkwwkhJL3IUxzGcMZEyynlu3Ygskp9vVeMDakCSiR6TGgQVJ47O3s9V4a1gAgpdQqTT9J8uyfleXydV3bW0KIOtoB4vE1cCGMx1orOeT67hGqtbaBDuE4MwMsOqq0tgUGGZT/bo4DM3jRifH6bWUndGNCWZY4OzvDYrGEMYw8l0iSpOGw3tXzyv43Em+MM58V/wRBKUmS44DFoqzijUQanHKEEIWGHQWijC1YQXPQk947IePh5a7qotvxkLcCEJwqL/gmW2vzOqkPJ6PpD5RMH0lBldsOuy8/7AJJkj7M0tEHSzk/5mr5urXMUnYtdj3cG39HgAu9uYe1FsaYbilTZhCi72t0ocxWWta7xtSHxtSH1tpMSbkgInkdb7xnee/NLmmdHODm2KAoFpjP52DmxkgRmrXB+abTz2D/23FeV2K3eeS12QOvfBB1LiVpkdR7pOWesCrrCFqWDAlRhfoOYFsFQS5WqTUcVbSYMkxy0Fgws5KyqeHgjDGWU8/hvRrHj4uhLLOwbPO6rnJrnZ6UWNRpqvdSZB8lSfaAhIs/cyo90g7Ts/I7ykMpXRCmJdaCYNkGAbIbIt8QNQw40iz0OSx7c3F4yc153XrHPbwLWGsCXgzzFkevGGaf2+xqk+8zMyx3X2dKB7EoliWKokBd137s7cIMO43Du88YBtQMntbrO6/7MEG9lCTJMWuzZ4xRfqsvKbaHAvDEIGPuGRGwlKoTwbDChX2UbTimwN2cuH04Eb6HFz63l6nWo/es9wZXqbwgojkg521BQNJSJsdpmj5K0/SRIHXBbMYxwUScX3awK7r+qvFn+G+9ZNv6OaBzjn+OeI6b3wNscHBI7zHUOTBUJLsrWG4i2r4m5arfPVwxUollXdeHy+UcRbGAsbX33wgLzul9lTIAE6zP/rpZ27CpPXWMUvdhmpdHVEGIhRTJaZo4PKuL4jWyAi6aouXAbkdsTcLO1k/aGKMt613LNmXd+tb27+ssXA1nlcQQ2GLiY4hR2uqmBZNl52qYWrHIsuyBVGIphChB0gIWQogyTbMHKs3fJyXPWTvBM2DbQLQrRBrJdesIMxCvlO26ZjjnHZBbANZrH/o4OHDeFqaxou3qg2wFF68i5EhIk8wuy89isfigqqoG8rgxCxhjmv+CXoaRYsvWF56kdJavJElOyrJ8xVqT931gPTcuAsYNghwRGW1aGBGuiT4b3W+I9CAQh5cQE2g8LgcHmAJ3d9dKrbXeY1u8ZoyZaoYhIp1JeSGQPnZcQYIEGmOFlHJmdVg8XcKNidJNzKClbJCQw8uOj/vn6VzTErCFtSYztj54Xt5lm9o6CNJqHvReWS7fKMvlbznPOTSCWYBHWmvHpFRYL1t4lfUfbN1AtsFJnX4gKg/WDYEqbrzPXGkmrfVemuQfai78Nt8lqKiotPPTlWAQ1Qxnqw8Ry1q7/AzBj9dhaJcTQWsNSU76j+GFEKIIAl6zvXvi9b+XcPl2J9raxIBhl+J1tmQsYMdj0kR07LY+CWtdREme5/fLcvlGbU2mKDjatDpZa22kt23mtfmMiTCcH763mNY2fbqJdv1xkxKv7TeYiauqup3n43ellDOj9YiItGWnB19J1xYxgsEXyw0jcHkryDEaP7bcQ70mJhGw2XJZvDafz98qyxJaa0gp+xDHOegYA+Y6jKMHq4xXEzpyvZb17DqEG03EYNEQwEVgaK33TB30gKtO0gPXam/KDbrezHPK3NrVMHVmVpatCOqzwJljzht/xvcPxG2tzeq6fCXch11KVTke0T9N0/QU3qPLJX0evS/l7GtlWd6CkgYwHc4bjavzfQj3+rF0BLr4hff76f7dvHjldim95wRH5yz/PDhxkEeCTBQv/HgO67q8t1wu3yiKxZe1qTzswcpO0ghsWNW+DLWrVGUrNvlNXHldP02lTLRCDhGQJI67VnXxqjV6IpgbT6wgxDGzYjgOQW1lyTLWLmhdK2NsP/dXm9COoJltwmY1YR0RaeuqN3TqBPtfNZGAIPeby4Re3gOLio0dE0MKmrwt0vSREKJI0/SR82WWc/8y5BDBxoJY+HsdYcfbKnnzMRF1vM4iobTXh7O0eR32vtOZ27zJh3xFC7tUwxCc12AnQbbXvhi2LI2zQJYgF3hAzJnHuW/OZrOvFUXxmtYazNwIavHzB+ggJXsuu14VCPjyrQODvhaXvc4q7nE4o5S6SJP8Q2PMhLUBsJKNsUkT1b9P5Kfa/B5blILHWMC41gdShlClofG1EbkAfNiT8BY1V5XdOXvbhdM7By6jlJynafooSrf/E8ZogQGrWRvS3uW467hNeLFCiCC4rlzX58ggBrOAMTrTprqttd7tPtvmd+Tfz0oc47q/mTkqb+Dn0Zjd5XL+1nw+/0pZLt9wHoUWwGri6Jh4/fUbdyrg2jFs12uhFBG1DiO9LdpBgDRNH2pT3aqNnbhxOV9YhhkP5TfjrjSsAxETkfaS9ZR9KHm8WJrvbFO2sIE7+37aCpSO08pQ5Z0B4zGwDzOvDyKB0TDbbDKZvJ1l2aM8z+9nWfZAqfRhWVd3vTaiM+lg8rpM3RxfR7yBywbi7cOJcP0K8aLFxmFOtg5IXVPRMgoS6Pg+WIJmQRDOJ7kM3L5YzH58Npv9keVy+Tpz6yLqxuiMEUQCAeIYo1HXBOag713vkAT8COqw9ReFEHKeJMlJUmefWKkP67o+DCquINzF13BXn6uCqiwQYvgfzKJa69yf0+RZYGYZfHzD9aFPoraAt/AxcNy5r82ckcJMal2q2awVLKWU8zTJPxqPx+9cXqaPyiXuxni1zyXjY1dx3kDA6zhSOKcbgWFgrTNWWG4477Wq9fRliHVCXBCYA7wqy/JeIFytqyOViKVo/I31inElcN74mciux730tAGYK1G2ax7Gp7Jc6/AcuKXnvo+sro5b4YL7gtdqRhsffRzepRCiUEo13wGHib2yvjGGhOs9UTVBk3HROkfEpMGiEjBjMMsmZxq5SjfGmElZLb+gTXXLst5lZjUajd4bjUbvTafT7xWLyx+vKjNAVIEDC89d7CABxxwnEK/WekBws809Wiwt4L5aBNVfINz+Oxh4feG3Ts2JTYQb5rqu68PFYvHl5XL5elEUrxljJrHDfu+1+uegZoeJ50hxu2MNLexrEy87i0mnpz53XPdwPQ7a4CohRJkkybFJsgcucNBxTiHBDe5dM+FDi0EpF80LON9d9hK3n8jShwR1cqYxs2pgjvd7YGsngTszs7LsAhjd/Y13NNF7WrtgRyLSUh3WaZo+mkwmb59KWRJR1uo1W4Ib2gq35b5BcIt/c2OJNRLsTc+EYA6OzdTx/G0j38SwYbix0lrvh6xJy2L+Y1rrXSFAKulqOPrPHs9LmCsAMAIQGzKUXOmMPjjMTReFc5iVJJ/jwUfmEpP1+MbpWok0GzsVQhSSiLMse+CIQe+53F1iGXOL4H3G7LjpEFePF4WSZJRMToxUl3VdH1a6vhGFBWVKqfOYgCnoJ+HgHqMbnRsV2EiZWQmQZtixMfVhWdW35wQl2E729/e/PclH96fTnd9m5p+2dhlC7N28Coa1BpKU1zGFO5KHKCGtLnn1kQYRg42G1QJpmkIg8ocQ/eyKAuydfYw1YffJWibTzX65IqD5qkLNbsdkHHPswivN9Z6SckZgVVX1YVEUry2Ws68W5eJLzGYiEjEHgsHHCc7GRDhWChgwhC+S3ZhXPMESAJISLF2WHbe4CRIEwc8J815XuKNI19ocg4tbk9KFkgOArvVeCO1ptx1ngLiKWxCREd5RhgVbKeVcgUUQ4jyUWNkO2XuwuePBhxgAVrl9wLpCiFJrlyMXZNMgtE2n0+9VVXVUltXrzlmmJbDGb7Ud76oWwQ5mAepgaHdyV+sQY+kWkgQtjM0A2bhrDkGBnirREFbrXDC3ibNDyFFZLb9QVcVrwaLnzP2kwZyGBRQwOzP3q8kD6GsgnBmcmeE2+675e6NjxVXtukTbu48Jk8ewKYhFcJlM0/RRVVUwpj4Ek429x64i3hjCuBg4VlJ6/a4Ui8hvN4+Fthja9BeJEG1oeoAxAGBMSGfFktlmRVFnxpifyPP8vpB7v7G7s/8Pg3WrKJaTVthq1Vl+zJEE3r5c25O2A2wImgc/ng6Ru3NDHx1CvnZpVYKoutn2g8up48BCiCJkp1wul28si+UbLs2XzUNWUGZWbO04MIwYGoXFFn8CaJ3yB8zncdsKuPsbvTDNRJhUj1cvHHyweV035t70Klwdt+ZZfCCgFwo1SbHwWocy5DaIYUO/D2uDA/WqP270MhpXQwCyrutsNpt9TUo5Pzy49Z+NR9Pvl9PynjHmm2VpARgnqPXq+8VCmL8HGCsJRpwg44XS9mV3tQ7N9bzqrON/63jgrRPE4rnkyGDhjtncWFZV5a1n5eJLdV3ecxChFZh7cybXEaMbr/+O8AzrRuXateLwt23X4d5AJ1wkZF88NsZMqqp41RgztU5GESRaC50j9u3GHRZGa5lzCUcAl1LKWqcDDecFtZvjqByct1d0pMxtcKNT7zkCWy4XX5ZSzqeT3X+cpumj6WT3H1dVdVTX1etB4AJkYyblXoz9ECGGT2stjK1hWcKGl9xwXtGDDK1eOHZ86muLQMPZHPtzGeaGBYMZuq7qo6IoXiuK4rXgZ+LmmP19OCNEqSItp8RoqroLt+oQ3mOYgzbg2/kwk2UIjjiyb9cyD3eed4ATbrkQ1ubdirjvecj5y15vCACSqI7ve9Wi6tN2OD/mCk4X3Ibd2yhZSKRUH7yPv6bH7RhVVcmiWL6xLOY/Nh5Nvz+ZTN4OlXuKgj3uM6AeU4y5Ur/P6J7QWjtL1EDykS7xts7qMTTqzBG1OeTWtXh3ISJtrM2tNZOyLF4rq+UXal3etda9I3cPL88MW28bOLAeNqyZD+rOy7WhQA/MbyTWOD8rs6si5MT4jkO4CcaIcJ4kNUukmYUEyU1QpiXDAKHxPlu9Z7wYQsQHE1VOqm9/jwwbjXnZGKOjAFAphOhlSeyaV4NeMmznxjgdbF1rFIU4OD8//6YUycl4PH53Z2fnd4ytDwD+2eVyKa2NBRbrtAMEz00Dnm0tcEQEJgsLA62BqqqgkqQhAneOE+QMPGRgxETdeHltoy3qN8dxqTBgGOMEtKIoXivL8l4QXP2ztMkRm3fiiD1gXvSIsiHg3jHAc+deC8/00i1s61qsTSAhlkRynmWj97yVbJc72ok2N0Kfc8d9WnZYOeJQnSqUgNMUhKQhjT7XScVSa515ruW5sR10Ku9bvYwxKMslzs/FN7J09H6e5/dHo9F7xu7ccFlszFfd9cZjX4F1vqtxv+ElB2OF8KFBMRdzRA63GHilNGqzCH0pha1cX+PvzG02nqouPheiNJzmwWaBETm9cD+a2e1UAztihwMDTpYdIty4DRaqe97CmQAkiNhPcgerMtowH2IIAtlglYEVWZ6O/hks8ZKXb1S6PHL42IW9X31jsXAct+sLEb77MIiFJBePFoQ5f86h1jpzXlAG5EOUhHDCVkddZTniwgwpAOtTGV3Ozr+Z5/n9nZ2d3xmPpt/Xu05QtNbc0zo29wZzKYf7gUCNUSK8WCFcfi9tDEDUxLYxt8n5bPg7mmcp5YytHQkiawmMyDJJwX+E2jIKDr/SAnA55ZIkOWYC6lrvV1V1e1nMf6yqqqNAP26nogbrxpCByEWD+7kFgiAahFYfsyai+YR/LoqgUb91BJqrqeHZ23W0GkGACxjYwuR1XSsG0qExb1CfbZSmXahbm0Hc922Y+R47B58mEJKIIGSXW8C23K/lggJa11gsFq9ezs6/6fMWvzcZ7/xOXZmptfYXFgs+YM1gth3tQx+3DsxRw4HjlxsWlPWxcbbn9E6RUYKZJZG88l2EdwBiYS1nWuvdWpd3vUqsqQRK3njkLwwZgDrm5Qg7+2fs6quD1oTQYtxusyBq+eoLhQ1xlPE23NyCBXy2FWaWBFFKmZykIZ8P2ZQAUeugbbjava9D0CwqItKWrFP7eCudIGIApYsIbnyGCxeabw+ca2HrridseL5VZ+qWWCyMNljMZhBCfCvPxu9mWfYgz8fv7uxTWVuTV1r/UmV06ixo1IlpG9pZiCSI2mjjZjxRpAURwbDfBcjGxzuGGDd/QW8bwwkg6HEb4pVUsxOcd6q6eLUsy3tOzdjFugIIiVWahIPxgrGsc4YBQfrnDSrBkCndcdtgdBl4l3Dwyld9jx7oR1oRPCZubnWKndJWIBsw7C2t9X5cgTK0jdyYm9xnAKLSWo2AS8pZ+aQCgDRNH/orDwKxWGthOeQXRLOVB4LqOpcY1LrEYjHHfHH59dFo8vZ0mj4cj8fv1PXeoc/i+MdKbeCcr3veZljVJoS/jTFNAubgoN7sBhHnHZjnoVIFzdbfI/LGbGytzbWpbjmVX32odXXUvp/VsP6o36bCfZN/bVj33CZeuQLrhkU6yA2H1GDP0q7qa4hw+01KOc9o9AFBLojI1EJUlTcyNJEWrfeTj9xwWSbD31Y4P11qNgRXboCc+TLvCoVOmPP5tTJjzMTYGnVtYIyzdMFyk9kx3uoDoUlJ0FqjqgrM5/O3Rvn8rSwbvZePxx/uTPd+M/hZWF3/4aoyTUp/IgGSBjAGQZiLtAYAWpVZeJGNoOMFNmt9fAgASaIWIMtrsH9zjCHBLCHgOC9sChLSgkptbVLX9YFLWl0dhffWmIAH36vNw2/eMcp5v8E0oe2+H//NOar3zcDr2rX0uC+qxfeKtpmV+hDedRIgm0opZ9b7IRhrO5nN+333/o7Tbq7kGAjug0HvCzQaiYmxquGuzAzrX0YcZNliUAMSAswObszn82yUz78yne5+Nx9P/uloNH6HmVVdl/dMXb5qjNmt67p1tmEBorbwSDge+8EGM3H439zb/5YInzZVUe0c9q9vbGKnr5W1Lu+WZflKi3UBp12I1J7RXMb9RHGGnR1qRRjrWRivai+cOJ92ARCRCebdkPvM13SbpZQ+klLOGWCt9V6t3WcgQH99syAsYcWxJIyNmSWsnTg/4sZpx0+2zymMhoAbowQzQ1tufA0At323UbFO78swIBYolwUuLy+/Pp3s/WaaT76/t7fz8Wg0em9//+BXrLW5gf1z1upJURRNfxQl5HCQImgcFIg0jKmdyqxNbeUENurme/CJAI/XhT6FuRjixm430rt1XR+E+m5BcxBfCwAMiPgdhJ3Mz2nHNBy7b8bCL/f0wBE9rBwbdMx5WRx3mxaPpyEkUhciEQUJl4WFStLMS9Vml2wytVhmVixoJSkJ4LLJuK+O08YeZ/HEhxcrpexY1IKKLObGQAiItN6f1vr09RWWy3m6WM5/bFRMvry7O/1emmYPdmiviT4wlf7vGcOoqmKF8zj1WY9IPQHEnF8IEVw5QV6V5vNJROW+OAl4dGjOw/M2cMt54E21ro6CU1OUpqDFuF5gC33En2vus/a9X4vzxuqMYBkTVzkPrL9xw/22XQz9LRwAmKyrXkN+Qtn5hAJkwIASohKJLCSpWaLUZVGWd6uqut0QsdATIUQhQWMvwXbHYe2Y2RFx4LZdaZk0M0lu8gW77VwI4bIagkHk9LJVZWB0BWtqKKW884zDr9rWYCJU9RLzxenPTcrJf7tcLt6cTvd+M88n7xOpc6NBMFDW2j/p4EMNo0PKo2AMaf92zFbAGIYQDCkJllzSPnidrxACWZIjS0fvu+z0rfl73U7kZAA7BgOkksfW2qwqijd0Wd3TZXUPVt8QYCUg59z4dVATLhW/PwuqrGWy7n3AWAuVJL5MFWBgIEhAeD2v8QKbAHVQb6xOiznwc+ewfQJ53ly8XQzOohNCf8iZPS0R6bIs74UUR8aYCQtRR5klG84aYMJVYw7bXsxdA1dLvImWiFBXVQdGKEq8/wLBGA1tCiyXi2w+v/yJneneb6bp6P08Gz9KVHays7P3GwKc+hRRf+Ly8gLLpfYGkVYdxgMBnY2Wo7H9OyJQQoaFdO5yXXRhwyDD6MEH5hALWN1u4+Bs5gwSmxPxBUbggz87sCDGu33CZGZvJexaF/vfV8Jy3FT741c7fOuhl/+iVG7svZ/aLInSq2qMC8KUYqFU+kgIdV4UizfJuAhirfXYE29jd284+IbnGjjeWL4cwUooJSCEgpQJiCSqqmpKMzF8jjHhXpzWGsvlHLPZxU8X+4tfGevJ25xljwBClmUPhNj/NQPjE6iYP1bXNcpyCWM1lPLcydhmLCF2zVoXuyaDJoKcE65SKqTL93h3czKX/lZP5OYv1LZwckXjwJS3O+vqO2dmSWxz2+ZKc1h2AA40UXfBwINAuAKbNA/PxBXXcdVn5bbbQo0ImxkAHWynlDovy+UbZbX8QuDERDQJ5wfHnDicKIJOTa6zcA8hROuPGiBvhCtjqb8sS2fCDdu+d01kdomVi6LYKcvl617IBFzdtSLLsgd7uzf+gSJIIcEAfevx4xpVVUGIILStpntqd4QQdQAoEmFnOA1lvJzgxwprkkwPEKAypj6squK1Wpd3vfP9Sjxi0OVG1zU4OPimGFM3nLQResNE9ixsfdfHIWFtrZ532xZj2/6xZ22uzxDZK0oilMzr3ClFwWxzEJVSOt+EqEp8QZCLwDmcgzkLFmxIOH9dIJSlaqR0ryZzfhS9cbWEI5o8RxDCx5ZFKqvaaBgGRBRBobXGslhgPr/8icl4/t+MRqP3kyQ5dmHjpNM0fST2b/yKdRXmdVWVPw9YFOUC1moPU1oVmTNbG1irwewgjGABqZJAvMd9zQD5Onfrm8vY6QIC6sNgmGghRcjxFuCLXQtBrLW5NTW4mQPrGXDX2d793TVW9GFDn4ifmtCuItI+dnraFrYl/32lKmUsGXP0ty/k/b7PH/ZeUSy+7EvJ3g4F9mLjhnMaaYq0+GcTQT8ZsrI3+JbIbcvGGLBtQ8+VUsgypwY1y8XKVm/ZQYHLy8ufmE4vfmq8HL8j5bQQQs6doAkkKvtkZ2fvHyVCFi6PBX31008LFEXl++kmlQ6YN/a/8FoGJImrzxxDhk3vxTMNAzgddFUXrwau2wqyTQ1nr22ggXfdxvm142o5r7UWEOioxmKOvA7vxm1tOaNNbYjjxseHfnu6FvS7PStcwL7Se40RLCOOBnCcWghn2EiS5MRlL6+Oqqq6XZbLNwIRO+J0gkisHgoSeSBsoEmZCstt5kYhBAyz9+TyMCJRyARBW4PKC3FufjSYCXVR4vL8TEyn02+GPA8xdwRIp0n+UbJDuHfv3l8jon/ZWvv1R48foCyXkLJrrAjE0HIr0eDdNE0ftp5yV71nUcRyQLzYWzVkI+Satj9WzG2kSUdzZXVjFg5W4Wac1BXS0IcT8L8z9fQPrr2w6OGXoS8OXNKrf1YiYj2xNRV7pJTzPM/v1/Xo/aoqXl0sFl+u6/qwrJZf8ITsowFc/1K2gZeBsL3KTAaCCVyuExXrj41Go4aDBMxnrUFlLWYzwunZyY+nafpwOt39jhDTf+q5mDHGTInARHK+v3fwX7Ilo5T6ZWbz8x8/+DAKhx+Ie+PWkKFUCimSEyHWGyc2tRCsqnV94FxRbcbsI7KZO4uhv9O63MQuWngr99XoGa4KvAztaa1fgybYHmh/ZsIdWgCxfjLK3+tDDsh7pKEJ/A+mTCFcPQxmV4s3cCSt9V5apg/LsrxX61bFxmyzqqoPKDJXh7HEXA9AlEPXRATkMGme58051tZ+bgwWyxlm52cYpdkvzHdv/LoEIRtN/qk7190rkS4rz3Q6/T4JlmVZvKa1fv307Bjz+SWC5BgMFq50rWggjVQKKk0eO02DKAmoBIkqeI2tmovdTsMEY4ydhmiJaKftZdI0AV6Vfn68NRIZ4M41tobWlZ8Xh9FbL3MvyAbijjhvmN/4M3wPDOUzY0m7qq0h5KeIeHacmIj0dLr7XWPqgzzP7zs4Ub5SVssvlEV9U5vqdlU1JuJuP97vQCnVcLpAPA4aOAghRQIWBKV0I1gFPbC1FvPFJZKzRO7t7f+JJEmOZZo8EqQu4EPu67q+LVzq1IdS7v/6nTt6T2v9V6y1B8vlElq3chd7T7Og+XC1zbIHSiUnRC4PRjRvngGs1xZ5i+M0MtwoRIEDvSsGk7/4FFidMTJz7AMRRtTBvqFtSJYDwBPvy9jir9uISIPJeueA7YoU+Boa5J+ao4cPE0pN1AR7n+D0kZTJiSvwPXq/qvL7Va73tK5u17p4NS5AHYwePh6rk5ooOJM7v4PwkryfQ1Oi2aKyDAuCtYzlcg4iwunpyc9PJpO3p9Pp94QSWjOstTZX3qfYBU2Q3tnZ+e27d+/++8bU/6uyWuLk5AmMaWsVw3q1GyRSlSHL8vuJyj4hIQqGWLooZRdb5t55cB2hFm8TGdacG+NN1qa7eCOYJlcXQdBCuL+MNY0zjv/dE6mPcrY+5BqrSUg8DYBJgAWBBcH5M7fYtyNgPSsBP69F0MVOZDjKmL5N/8051IU03WudRB2wbNBQuELfLliwqhdfCtlggrrIuwUeak2HRLLBvi0Tab2lrGmdwYM1LvaF0MZguZzj7OwEOzs7P7u7u/udiZQzqdSJMTa11uyFcfuUACd7e/vf9kk+/oJz4jn3+uTWwhZgg0u1qs6E8P7Qfg5Drrn+fAYBlZlV0MiEYFQa8PNtcW7Xz4GZFcimMeGyVxX6P9xHL3dxUJW1rLlLzhtVZUPY9bptW51vPHGbtv8gxLiL1m1bfU2Hc9glNxsuWJMhwRBgTl1yRlaxl1UrpCXHri+b5Ta/b0x90Aoueq+qnMai1uVdn+l7r6qqI60hAxwILy34hhADkgQ4mJPhAy9rCzYWl7NznJw8+ep0Ov1FpdT5eLR7wgylfbJBgnOiB4syTdNHN24c/IrPxvgLxhhURQlrAYtWgEzTFInKPiGVPHKwgQx5smhIhligV9qLiLRmq8q63u9z3fZ99N8th7IMzpEJRrL3uLNWw3hUIQIxBrM2twudvBtoHzqE34Yw8I8cKlxNuE/f+tc3wpf/O2R2DBynqypTZ9ba3KnayFir94xhqbUjXq2ro/HIceGyLF+p6uJzjiPXh1praUyNuqrCOPz9JVwgSCTssXZFpC9OcXq680uj0ei9LB29z2zzUEzRK/VVcEXMs/EPb9689bfm8/lbVV3cW84XWCxmvo6ZcwrK8rwMFsfwfHH1QR7wKos0Klnw2+1Dhv77an17Ae+XgbYwou5Fl3ivtxBrx63Kbwgbr2th/l5KJMVQ//Hn07c25uoqzUTn3v0MMezqvjE4AVwaUwAgJc9BVBFIK6VOEgvFWfZgNLK5tQ5OBGIOQYlB8NO6PiiLxb0Q8RCEK2slhBFNLl1jDKwpcXF2jifZk4M8H//CeDx5O8uyj8E+mxCLSko5YyZtrSPgLMse3Ll99P+qq8X/slg44a2uaxAR0lQhTdNHSZIcS5GcMMh443EWzzn1CqEwUQVqE0QHYc2fI9GWT5DUJksEs846xOe9FQwYmlviZXJV64MXmfWcWAXtDW2OpNgIG553e1mLILLA+fAfdDDdVfCk//sqfHKhLgSAICopnfFDyuTY2uxBnjuXSmMcTiwK5wtQl9NXG8xcF6/WdS2qqoBcSihZASxQFAWKosBsdhG0BN/c251+n3f2/tFkMv2eN8t6NZ2rRiQkWCl1vru7+92Dg5u/dnp6+nMXF2dNZIWUCSSpSymdadjnWpPh1TeLmoEhYdglCVktAcDczZcROGRDnMyNcMrs0jTBtMQbx/q5gaxurB09L63nvsAVxGvR5VD9msPRil2p8h7OH8LAQ8TUExwcEQnwOuJ3ExmsUhwwbmd81plmTMB1dmDbIyJjPSdmwGkg/G/SxvnJOOMAO8g5t5NUC6XUiQrjt3astd7L8+q2MWZa1+U9Y10EgsPFeq8si9eWi9lXl8slpDyHlBJ17Zxvjo8fQ0rCziT711753Gs0Go3eE6QumOzImvomAAiymdWuFsYoG/2zg72bf/fi8PxbF2fncrlYQBCBWEBKdS5lcgLDmQDADGVApRRyZpkVCaHDggBRxcxS+cVu6voWm/p2MP60Apuvu4Z2a48FUBIc1R9p1YJx7gnm1teY2IA4KkdgHaRgMiBKPQ25PGUh+w+RhIWAILEd522IrkeM1219TjxEmNv2T11BY8XnYd39r3NOH+NF2+XgIhQQlZLJqZRybq3NomTZuyGNVK3Lu+Vy97eKYvn6dDr9qcvL83GSZLi4OMNiPsfs8hwffXQfSql/NU3G7052dv6xEHKptc2IfAEXmDGRuiCS8zwfv3PjxuHf3dl59KeOTx5DkIJLbSrnxBCdeRrIMRyXzW2bzbph7cMtEGNXowAEV002tslp4eepc24MA2I9r+vTdDLmxEJbOOdK55qrHgBoOXKfUz9rW3f/dfg2wIXrQpVo/EMxXCsE3GjFwg5hOfcHvNAnrBCi8E7khZTJsRdmlLHZx3WWf6z15Afj8fjdyWTy46PR5KfyPMfZySlm8ws8eXKC0WhCQiZ/9dXPvf5/mEx2vyNFckqChctZLEoQYFhPVSov93b3f31nZ+9P5dnU55dwuY2NMdP+vMWLb5PmZs1xGRNfbBKPVWEhK3vMlePcEkPE7C9sufDa1pqan6tO9mW2F4mnA7daZ+AJXL7F1JDx8YAjYyIhUk1CZknq0lq9l2X5/clk8oPJeOefTCaTn5uMpl969OhTXFxc4OT4DJbpVp6P/zwg5+PR9PvOnN1yfa31nveee2+Ujy/zfLyzXM4dDCmLz9dGT7u61xa3dneNwciRtWWvhgi3S7yrsX19Lh3Oi78Tr3LzTe1anLXfXgThXiVcPc/WCi6eWMXmsJb4OmaWMHbi7EPhh74eWpQt8TivNXYGh1KI9JFSQJqmj9I0ezAej9+Zjnf+aJZlv/zkyROcnZ3h/PQMH93/8I8ZDbpz596/OxqPf4+kWHh9qmRmEgSTZPkHo8n4dyeTyU9XVQVba1RVdaC13gt+wdYyEO0iA9hft4txcxb1IcLqE28fE69AhOGONxJvzLmvred93gS1iXtuOv6s4xhSoW17fsR1DaG32MgJmDG3i/8GnNJfgDiUKiByljOl1Hmq0idJkhxPp7s/++GHH751cvIIjx49grH4GSnl/NbR7b8xHo/fIV9nji0ILCqp5Gwymby9u7v70xcXF9BaoygKhOQg5Nw64QJKh3Nb9OebedhgtYpvY71sl3hjzhtDh03Eu2qVW71vCBO6knidOXGrAkBbtXiiNmHaod+3gQmdcyz38uv6+w+MBQBEP2P4mhbO88p/V1MDUTYadiHgJKiM+ycWNdikDAYbgISLSg5J/tJ89MNdQVWW5h8x819SSr15cvIEZ+cnEB/hFw3X+3fu3Pt3syy/77MBsbUAW7Lj8fid/f39R48fP7xdzOuggnvNhe4ka4XQuIVFapjKUC964JxBwu0TL4AO4cbahvB3jG37wtxG2EAWuIrz/ijw7HXuuY324qp7eAvWRv8lXlO3oeGwA95ZRKRt328AYGZRNpK8r8TpvdOkc9XM7ydSze7g7v8jS/OfB/AnHh8/wqefPgCT/Uae5/f39w//bp5Nv+8LdEtrbZam+f2dnZ3fzvP8l+rCxdD5OLldIeSs6+y+johbR/xwzlVz2fQHg9Z1YTVr5ibM20ABdAk4/uyNfTNs8Bz3mcyzQ21oQtbpe6/qIzbnhpexCatBOAtS049tiTbCghshRQdCwJfZCjUyuJsxBmwmzrABsLXKv45OMROnlWgLHnptxWKys/ubwcigUvknP/roAzx69CmMMb/8+hfenBzdVhdpOn7H+TCLKktHH0wnO/9kOp3+0uLyAnVdolguv1iXyzcTKQsp04eVD6C01uV+4yZbpCh99klF1E067Rz6ncm4ISRyOl1Yn/wkeERaZ6QQRKh8AGoIAXJ9aQAu2rpTzSgQapRpPvzWD/MHnM6X7FOk9X/W1ie2F3WPfv8BLnS2cRIrxhWO9MVDWLd7o+a3QRg0sDPIoXP614Z7TcY7vwPYzKDes7b6Y4+Pn+DJkydIk/EvCSHnN/Zv/Wfj8fR7jsDU+Xg8/d50umsuR6eyqEuU5XJ/uVy+nmXZx0TZx5IgmahkZ3bOukyjXbwhs45bSOGMQYtbjzO6Yth9vBt0tEK0WX2oZ+oNnLfbd+vcH/6H664tsD3PtgF3rRXi1sGEhgNzW/KqT8DMrEAu5Jua2LjNSae5t+039/Uct09wkfk1mK0zx+l8+iiYca+SehOl0SVi57NhiEw2yj84Ojr663mePpQy+XMff/wJHn76AKbWv6y+JJdZkh6TzD4hQZWS6aPxaPK7+TT/w8VZgeVygdnl+R+bjPOPMB6/CwACnBqwdGNrXSXjcfvsmLOQQrbznGgJyrJxUQ8e7gaXRvZZIFuua0HURpe4QMw2z240h53PeAHE54S/f+ReZZvaEFcaICq99W/hmJ8L20tX5L93socPD2yYU/bbVRBobf/+N+dFBiQqe3B4cPQ36ooTQvJnHj58iMePHyNJkv+RMWZ6dPvV//M4G78rKDmZTCZvj0fTP3xxcYGiXODy8vybBwf73ybYEbEdMcRCQjQm8ZVHc5qJInij+ZnKAlEGrurHOIxpqYtv+1ksB561w3m7HN2u9BfO+UwS71WqnHVce3VLDr4XLso4XNe8uJ6LZBCyWm1C8PcNEQKrvqzMLIN2wa4Ud4k9srYzY7tnddoHbcwYJOckYNIs++jOnbv/9zwfvQ+Lv/LRxx/i008+hjXmz2ZJ+iRRR/9PJdPH0+nud0aT6Z8ioca6qrGYz/Z1Vd/q30cwJNbotUNe4nbeuyHpQ/8dhwzWLw8VBENIANRNw7qJiIe+rzvvM0m8Q+0qixpHDjUtx25rqgVoEQQif6xTM6E5L5h720DFebgHM0uQCzZszK89og3/N5Ud2IT5w/EkSY4BQJvq9nK5nCYyfXJ4eOtvWc1pmqb/+gf/7Pfx+PEnyPP0f8Kw6eHB7f9kPB6/u7uz/w/TNP/FcllguZyjqsu7Vte3SIgFMacWFmCnpx64t4k4b9j5PExoVV/x8ZiAHXH62fOJt7EG54Y+mk/uHusOzGHgUFjwuXPeF+XjEFr/ZW8SlIjINKmcOoRLGj2sG/Uj0WTLAagRauK8XKyAthYyEWkSzg/QY1vDzK3HFiJBzfsN+yurEHO3rhnDypJVIuB3yIUUyfHhwdHfUEqdL+cX/+bZ+RM8fvIJhMBfFlJe7uzsfzvPJ2+P8ukv1mUFXVYI9dKSLP8gZMsJi703h65ajxALEurMAsYSNBtfwgurRoQOXNjQhn7flIR0LSSBI2DgM8J5Y8Hraa91AhNxIFwi0oFzWTiXTWaffggudapP/aSc9G0mxtjcGJcSipmlhCtEIiTVcdFBx7FtplT6iIilIFm4jJXq3CXlIM1spsas1iwO392z8kpNjeh3IyUsDDKp5Nxqs8PMsq7rQynV+XSy+49f/9Kbf/PDj8Qvf/rpAzx+8hBpmv8r1pgdMJlUJUilgDE1fJKVI5mknwgpL10GQDF3+uYw5zYH5JyIXBmAXvXPPmyIjQ5uvAxmOAPCAHbtnut+l7LdmGLOC6Dj57DmvTvitYB5GgJa5/Ow7ni/rXLS1g0v4M2gix3SDAhBjU7SRvWLHf60idYukDLk3425jPvv8jhoC2NsfWANyNj6wGhOLOsdCaIgwISsM4F4hQBLmZy4MHo5F8IlCXFFo9V5GG+c0C+oo6x1WdzBZN1OYNOw4Nw4zZRIFGzNRArSLqupOmcmAyZjySZJln5ycHjzb1dV8VpZ1N9YLGd4/PjhZJQmv5Ak2YPdSYq6SLFYLFDMF7fPLy9+Mp/s/gaEOq2r+lAIZFJKTcRKMOfMkDB2oqEBiFKSqCURk2VpYmdzDMEFvYJXjdGo67ohdAI6hVRcohZ3nYMUgM+zATZtEu1OckFYJEmCEIW8su1uwmLPuwWCaxeOy7kbCNeFwHT9dv3nCv4NuXeZQ8i2C8mx1uYhhNt2E0g3HNu47TAPONadp/fIcicFVBhDDCGIXNSxjzw+U4kolHRlB9IkORVCFILUpbumWzejff4GloTEggURaUFkiciCicGytACcx5pzEM/z8Tu3j+793wDg448//Mb84hKnZ8f3dibTe1ISRplCXUvUdYnlcvlGXdcHKs3fF0IUQiZPmM2OWzwsgvFEMDpMbIh7rt3SyQK+/ECcGiDodhHpafscNea8rVDXNR/3rwsvcQUDbiLgbTnr6jbZ68dZl/LufUXJFgRy1qcwlu6WDQBUc5OK1MVb+XSae225Jb0b/FpDCHc8riHMzNZm1hMzjJ0wzLi/UMLfTSks/2yOiEXpohjkLEvSJ1LKuUv+oc6lUqdSyrmQohQkFhLq1I1fugIuljP2AWCWnHM72GlLQFYRC1cWClAuiyPJ0Wj0/q1bR3+9LMt7ttb3qqrCghbI89TlK1MSRlcolosvG13daZ9T7/d3M4ZNGWBf+6NRlfUFtlhAiz/bsP8u8YYqnW3e3TZNa4f4h+S0DSmtHGE8JWy4ql3VV3+ROIjQuikKKVZqSQThJ+DXkLU7JAYJ+QYC4YbzuOefELZo/73D3QlgxyhYglsjQxiz+7R5XfMBs82ZAWYb1GEIECORauYrGD3Ksvx+Nso/CCn2fQrW0sMSf28EM6wiiMLZW+MJtVkwMLVjIT0eTX731q2jvw5j/9WLi7Pd+XyOWhcgawDYUAv5ntbVEbHZFeDU8nojDREQIpeByMGGN+t3A411QoM2uEKu4GGOOWwXNw9pKhwH8bWB/TH5/LQFwaS4aoYNExO4KTNLeKk9HDNW7wBtcZNArB4CNJx2NaNNKEel90B+DC5NTJSABK15tzcm4axxbIi0U7d1VWCujyDsWOmIt7U8AcgAZAXzRAhxJKX8YprmX0wX6aM8d1khkyQ5zrPxD13+3CZEXZN/LhcSIpbxPDY1OprxqgsAkCr9ZGd37x9Zq/dqW/+Pi3KB5XIJqwuXmFoaJGmOqiw+r03xqhDpI0mittaOCU4bE56JmRUJFj4hdRG4o/XFE93fIetl12iBiBhj0zDCf6D53T1AOL/rmON3vvZB2WWK7Cfg+5FqG2JiaEyojutUJMBesJEx0YbkH/GxiGCjqFebk2gTR3c4/BWWr/ZcltTNuuO5sMv34PXIcE4t/q7BpAkXdKgNg2qJqqpuS5ncXi6Xry+X+Ztpmj2YTuvDwIkDtPBQycEyl58/SPEr1sBo7jKl1Pne3o1frarqSFfFnzo9PcblxQXKsoRKa6g0w3x++RO75d4/HI2SU1BTHzj2bzBhNxTCwaDA8QLxuvNaB5qYeAlt3rbYIScab5jfzmf8u0uXJUFSDDrlxNcOvsSn0dcOww5Rxr+1A3C2dSFcFsSQVqjNE+BydDli7HLUmLMydx2/ndqryRxpvPNJY+4dgjEx7h363et594hYWmumcW22NoTbe1kxQxKBLMGVd7NgNrBsYSygtUZdl5O6Lt9SKn1juVx8eTQav5Pn+f08G/8wz/P7LqmenEuZHDeqNqaEGQlBLsBAKM0lIJw+m82ESF5m+Wi2s7v/a1VV3V4ul9+YQToOvKwhpMLp6fG3dvdu/JdZNn7XZYsM+l5RMVs/D2AJgiKhlZBLSaIGkFhrYWyIAm6J11rb1DoW1hFvnExwowN6I6B5wm1LESBNU5c0MAqP70OQwaqRDbFtGXHQEXj6zjAbzl8sFq9VVXXk0iZVt+PfQz+xqmtVuFsNaYm1AWCRDt23fyxaAI0ZNz7H9x+yo8vOloYuRwlbpftkn1wkqI/alyplndV1/Wpd1wdFsXwjy5ZvjMfjd8bj8bt5nt9P4VRuzMFl0mlgyPlohOcmtwO4cQihzrMsv39w49b/p6qqo/ns/NUnpyeYz2cgIXF+cor5zdmP39i78V9TkpzA2ikkLTy27yQ0JMHSY3LDzEkX33aJt+G8ooUM/fi11vq2Ch+cIEggIZtUVVk6giC5ck38fSOhPa2+th2djzQIcEA4IcAYu6e13lsu5185Pz//ZlmW9yzr3Rj/RhyzcSNsMGnI9N1W1fNEBwiCBVgw2/HKcLqWNMRj65/nFkf4m7TLti7n7pidxJamZkKjQtXumATg6qRZayFkNzzG5WsoJlLK19M0f70si9eWy8WXJ5PJ2zs7u9/Js/EPlUofEiUnWutd6zxotRdsjCWbEkE3BgWA89HOb7GVi5uHR3/j4uTx//r05AyzyyXOzi5wcnKCm+enf/zunXv/nkr8QtCcsUDpuZ90hhvAZ5Q/VkqdgznnhhjbHAzhGZp58M9elmWzSPthQKG1CVKkzyvsjo/HU4xHU4xGI4xU1ilVEM93AxuuwoDP0hr8hg52VNbazKeNP6rq4tWw7cf60zijdzge/va2ct2/RwwDeuNQ/XNjw0V/jEN9hMUVJq8raXdCMftzEPeB8JrdVly7cHVToaqK14syeb2uy3taV7d3d2/8ap5Nvx+yuoc8SkHglEJdkGDhYIqz7BG5aAxM93/t5q27f/JidvnW6fkFZpcLnJ+fY3Z+sVsUxWtJkn0sRPLEMidhdGwhINoKS4F4iejIWu2Th7QQoO+z28f9MeeNCTiGEe44Q6kUaZpjlE8wnU6R5yOQXs2q3uG8g7Pde3nPqj4LxDhEGMEJxG2NrQASf4YQlpgwmdnEeQn6xL1mHB11VwxD4j5iQcgLZnm3J2GISHYzoVNT2bF5OSHroXN0RRAhhJey3b7BMDCoXcQvihIoy/LNolx8qar03t5efTjdPfgv0iQ/UdSWoyJiX3aNUxZUMEvNTIYIUEn6UCl1fnDz6D++XMz/d4+Pz+V8+RFmsxlOT0+xWM5/bDQavacSlz2yYRwMAcupy4dHNuQ7awjO+JK0LurCw6DYiiY78Mjlb1gNfY+FQGaG1tYR7miE8XiM6XQHUkpo21VStYTr6rO9FG1Dn/jJW6Xy3FU+z01+31dXzIzRe3XdLYIdruljXNvNLbA2z0Bofa4cc+H4794iUaFwXsDH0Tg6+bqob0FaJ6ggbH0MZvLELHzCEAufe4HKov4FY8wEQp3s7JBOk9EHzs0zinBgUbm5AQRBhqyhJORsNN79b27dvPMf3blz9peWyyUuTk9weXmO09PjX5pMJj+YJqPfZ9iMGQlAJnjBWda7ZFkliTpP0/ShrzDqn9N0iLfDeX3yQJdYUA8kJek+vzvuLGlpkmNnuofpdAfj8RRVVa1Y1cKOF443nHVoi7wunOhrJ4ja6F2/1THgBIskccSolNNVhrRI2lS3fVr9W0ElFjhgX5CKW+AeMQGSrxrP1G638Wd0bT958kpOtthQ4UzYbW0Ey9pxGNu1CPlqus2/RpNObbgMe8uTJAEONXmNgdYFikrDgL5pCcZavbe7e/AraZJ/GPAp+fxh8LUkiKFA7TMmWf7+/o1b/+nRnfM/OpvNvry4vMBsNsPxo4ev7+3t/czO7o3/SjAAQ8yWUwgECSq1bKbBwBLqywUVmPWvuQ8bYsLtY96YeFk4iCWsW8BKJRiNRtjd3cV0OkWWZU0Bxi49ebgmnN54o/n2WeFCv8UwRIjkWMqAqeQ8qMS01nuJKu/VdflKSB3qK0WuaEVizydHYE5NtgIPfP76WDiLCXgdPIphRMzlqXW6kdzjts0W2sPE3DF/DjtdUxQObgxD6wqz2QWs1d9yURXqfG9PzhOVfUIkZ+3uJIoAuajxVQCUUOejyfSf7N84/P8eHJ58+dGjB9B1icePH+PWraOf5Tv6gIS8ICZtjU3Z2pwEC2YzZWYplZxnWfZgNBp9oJT6AuDUfRamUwEpaBLcomu5bvyMMfcM3+vaFRmfjMcYj6eYTKbI8zGUTEEoEIwX8RwTubysRNeMYRsiIGCTPjhkFOw4WDTXu1JU6lyQXDjPLZsrlT5SKn1ozPjdqlq8WVXZg1B+1RfoGFhwjuNa6z3KQiZDq/cB52ziOb+wlhPLDi/GuuKhySWSZfi9eVJEHADGZUYMUbSRd1VLiNziPhtegrvHak4u510VKgsJAHVd4vKyhrX260T0l5nNdHf34O/n2fiHTWVQS4ZhYWAVESC9A5BhsYAQ852dnd+5devWbz15fPMnT48f4+T0CU5Onry6WM5/LEvHPySRfuoej1Nmm5LlzJKVRPIiy7KPx+PxO3mef+Hy8tJxV/+cMWwAnBgaiJeZIZRsCmC3Qp1znQzHlFLY3d3F3t4exuMx0jQFW+owhOh9d/6+0tI0gBO39jojr6cFuNW9+sbMyhq2bEEsWFnLCUBGCrkgJUql7EWSyHmSVLeFUOcuB4Eoja1vhL7bOzXCXxkRo4KVS4YZsyVrWe9YAwGhd8Es/PN00nXGHMJ9diNmXRBhq8tt3MqJBrlvTJwBHsTE3ZXUXSHCuCkhUDOjrmtcXp4DwDcCpxX7okxU/iGRnIPIMJA6lR4rA6qYnb+KEKJIR+Mf7B8c/L2Dm7d+cjab4fjxQye4Xc5+gnbURZarUyJWTDb15nhFzCmYUynlPEtHH2TZqKl+pCMtQEy8lqiBCuEZATghD0BTSMXPkRACWTbC3t6eJ94pEpU5vMtdwh1qg8RryVlbwMLAIaKV6obbNVHG5VBXsCaMAgHG6t3m3sySBGmCKKTMZs7unxynafqwLMtXynL5ujZVnDu22S7d2Bz2FYLmLFgxiwWDMwFRQJIB0ocBvzaYuhEWTerUV6FqjV4haqBbh42Cryp7U711REqAk86ZXc5ZaxvijJ2w/bw4Iu5sr44wskRCCcfRFrMzPLH664KhFAm9u7v/62kyep+lPLeWjEskbTNrHV4N2pQ0yT8cT/f/we2ju79wcXHxjScPH2F2McenDz79S699fvT+eDx+Vxu9CzIjMCfsiy9aw4kgstPJ5HdHWf5IKXUb/rmMAUgKGMPNnGhjoI3p1EEJ6jFX9FBCEMFU7ns2HmFv9xA39g6xM9mDUj6fg8//AESJNYBGuAv5ereCDbHudZvz112/7fnhXmwhCKL09XNL/7+oKjkPAl2sO24wIIsSRMYJL2SIoNFEDDi7PTMrpdQ5M8+NBfvFMLHW5mStYGZY0zqexEQc47kQyt2HHfF5Q9fFnDnGyEBsdvYcmxhShvJXS5yeHn9VSvkXhRDldArIJH8/zrtgWSyNYSWYM0tuLlWSfbyzt/8P9m8cfmM63cVyucSnn346vXX7zhu7vP+rFPyE0exgEi6Bd5Wm6aPxePzuaDS5nSRZY4QAurpb9CIt2mcMnLjLSfd2b2B//wYmkx2kaQqCdGo2W3vn8xU66vw9TFC83gvsRbeGcJ32ACBACjlzafRJK6XOlRKl1ulDl4vLTAOUaAdrMwYysBfefLSwaOR9kuQjJJhZCes4lpB6x1qbSe9j4U3SmTXd4n+drdI6DtFy59b275I8rzqfBAEnJvjQ4r7RQIuQ24tQVRXOzs6gtf2mktknRHI+3U0/8cWxXa1k4omfR8NsJRFYKVHs7Oz8zq3Dm7/15Oj2Tz55+AgffvghXvv853/+xs0bf5+kWATI5WPmpDGOg0spZ6PR6L3xePytFjpoQLTPF89D8xqIIUTru0vkssADEnk+xsH+IW4eHGI8HiNRGSQJ1Lpu5qm/4/Xn6qV5lW3ivv3f+udZH0gZ3AallHNj6gMp5byqqqOyJG1sfcA+8DH6P1iGIHyP9caOQ0gRp0EKBMzWjrxzUBoTcSDEmKj9iP3Eh5fWdd7ucqUuwXY4uG2vccWyFaQkaFPh4uIMn6rkzwkhSplkH45G43ddd25hBtWZZJLe+5PyNH2yu7v73Tt37v3k5dk5Hj98gtOzkx+7Obv9tenuzj9m78EHiFoQGWvMREo5IyKTpvn90Wj0aZqmd4RQYC5hjY0g0GqCkLhJ6WrQ1ZXGeDzGzcPbuHHjALu7+0hU1jx7X0sR0UgHqgGAApNdF8W6rW/Di2qBqL32IHM+DXKulJxLKWdCqHOlinMhRFGWonDeaXov6Dr7emEfQOiifwnWss8I42tXEFyZU4qSigjhKz4KmwvpuLI19UFMuHXNTdSAe4Fui2fiqPCZr+boS+dRg4yDQLMqNBLJRlMBCBA0JAmAnGXr+PgJpJT/A6XUubx5+/+djSbfJ5KRr4oLDA0LUQhRjMfjd27duvXrn3780bc++eQTPH78EHsHN/78eDL6fZWkD5k1MdvcUGvZJCKdpunD8Xj8zmg0upMkCRYLgmXTwIJm7JFGBpYhSUCKBMSANc7lcX/3Bu4e3cONG4cYj6ZeeAUCvOgygrW08dmIHl7XetqJngONKF30Lhkf8KittbmrnuMEjn4f/RYJextzklGbv8sFXxInYTxCiFQINLAiqIoAwPAqRw3f2auaHAfGym+xRA54tZTxzi3sCKYslzg9PUGapn8+SZLjG4k6ztLRB2iK+fndA3pMxEqQKEej8bt7e3v/6ODg4Fs7OxM8fvwQ+WT81tHR0Ru7afaxlHJmdHBNpca4o5Q6H+WT3x2Ppz+XJFnnuZrvEWwIO0vQqlRVDZDE3t4N3L51B7du3cZkvNM45jA7iBg4bNDnbmrPmXj7FrBnLQIYoomdd5o75vMfwKYhp1bEoXNrbV7VxediIlwl4BAB3CQnyeNz12lHmr6EOmNrM7DeF0JYIBGuQGDdTLy1FjBdE6nvs3PMYV8R/baaG0F4rmzRVtYhn/CmWF7i+FgdKKX+opRyfuPG4d9NkuTYCbwh/wTnQtoU1qm+xuPxu4e3bz165eyV2/fv38fHH3+ML33py9/Ms9EHSnXzl1lrc2i3gPM8vz8ejxej0WgspYTRoUggoVt2ykJ498ZYsNvd2cfn7r2Ku3fvYW/vBpRMvAZhVZPTJ+Ah/Lsx6cWztk0aho52AK2qKya0QIy960ICD+uMDG2OhjzP72dZ9rHXIjQm3T4Gptbn10TfO/+DdiM61tFVD3H0wG1cxfUEeZ4jz3OkaerKqfrjSZI0aqEguAWuXdd1U9oqNrf2tR0hragzYpzj5OT49dOz439pPr/8ujH1Qdgp3A7ki7kYxwzSJPvk4ODgV+7evQvLGmdnJ7i4uPjpxWLxps+4LuJ3wszKa32OR/nkd0f5BFk2AuCMKUM4NeBSrZ0pfDya4vbtO7h393PY3z9AmuSQMunIAM17N6v9DDXlM2Bfi0NuG2ERq7GGfttE3L3r3fiYbLyVEXMCggY4JYZMlLqYjMc/JEAs7OJNbet9Y8w0Tl80dE8h5DzitlFoDCshXLhPvBBsCKG3Nu1jVDfZxpcpBQQJkKIV4gsE29deAC3mC84pAr52Wev4CSKClApaM3S9xOXFCY6z7OfzPL+vlDqfTNQ5s6hALAWRZWtHktSMvQl9Ot39zo2bh1/PJ+O35udzPPjw/sFkPP3Z8Xj8rpRypk194H0whGVwopILyep8Op1+b2dn5yfzPMeyXDT+vMFq5saVQKkUgbhJKNw6uoM7d1/5cG//ENOdPTAT2FoIkg12JghYW69kTO//N14L9UI57zbtWVRwfWjQVm3PPh6NRu/FBBtzeX9tL4RoGO8O3HPTbtL5HjhxcLoO/0N94JgTB24czgm6UycQtty4rmsYX1VSaw2Q+75YzHB2doLT05NfuJyd/wtluXwjREZ0/ZbdbpJl2YPd3d3v3r59G3me4+HDh/jkk09+rizLe6EwTPxuiMi4zO3Zg/F48jCYcn0cQMMhw/M6GcAiTXIcHNzEvbuvndy987n/687OHpy2gkED5Nftb/X3eI57pU2fDaOuu34dx7uacJ2yvK1sGXmMASEfrGqcUiAXSooKWVDWsySUC631njWsfGaaxjutr41Y+1Q94neO3zbndgw9PNbLhkidvlY4cFD0x5kUg/FDaw2XFMU4iYJsQ+ANh4dFXVlcXJ4hO87upan601mWPRBJ+iAR0qUPsGTZB10yMUmlTrNs9N6do3uYn8/x6aePsLf3EFXxxS8lqTpz/sIO/7r35GBIno/f3d3d/c7OdO/PXM5mmM+dvwNZwGqvfWDAaguVZdjdO8TR7Vdw9+69v3ZwcPPvCKG8AUI0ljiCnytq1Yv+vpveyWdT27ANpPDnxVqCxuHdcYj0IQPWqdHKV5y7pbkdVEYRAffj9zqeZ0PcOubavo/+uLz0PEy8fdt/rPONBT6irpDXqOZgIBVBSsfRiQQsa1RVgfOLU4zG2VvT6fSbKk0/UaPp20SkSRCHZ3F6c1FkWfbg9u3bv3P65PjrH3zwAY6PH+Ps7OQXRSLmOzs7v92uR2/iZ1GlSf7hZLLzO9Pp9M/ked6kbYLpWhGTJMV4tOtw7r1X/ubOdO83hVDnRttGi9IKpd25c1O2Gr8WzyHwgowUQ/rhbQkSiFRYluCLO/fOGC5w11wHuZBCVHnmUiYpKRdlWb5SlIAxZsoWsMyJLyfV+AqTE+wlmFOnaoLtE+vQMzgoDq+5JZ8rhBrOEifQ2NTCywqwQcpRAzGstahrA9Sl95loMTFJh6/JWsxmFzg9TTCZTP4lmWb38zR9IknNiEVJbMeWrC/jSkbI5MnBwc2/c/Pmza+nSYL57AIPH37yapJnPzGZTN4GSZemytfcALODDln20Xg6fX80Gr2epinK0jS+zAH/jvKJhwuv/r3bt+79e6PR5G2XVEZ4PTrQaBkEAVHdYgjZWdjrOHAjVa4jhm0JbpvWx1Ev4n6RtqAQpC6DFsIr2N/3YS0FAPTzPdgm9H51XAP9l14D0dnyV7f+1cmPhY/efVb+DsQcsHKSZJ7buqUStBSWja+/tsDFxQWePHm0f3l5/jNlWbxme2FV7LIAZdayGo+n3zs4uPn2jRs3YK3GJw8+wsXpybeqqgq7VKN1Cc8fGSyQZSMQySZQkjm4Oe7j3r1XTg4Pb/2t0WjyNkGUzM6SGRzb3WQwgnEizA0Al2NkA2wAVjhv2IaHzarPIlx17jKghdiOaHsc19dMCKEwoR8X5euEDilcIeuQXilR6qKsqlt1XR/W2rtGWk4ZnDLW525wWghWbncXJTMbyzp1xrjuLFtykKGPb/34Qp+D/9utNHhrAWi2UEfEWhKMERBao66dixWz81pjy5jPL3F8LJGPp9+ajqY/EHtqNs6Sd3y/0lqbk4SRUs4kiXpnMv3B5+7ee+uDDwo8fPgQt4/u4m5Z3pPK+flGhGsCLBuNRu+Px1PkeY7Z7AJVVUFJiTx34Ty3bt3CnaN7/+5ksvPbTFRqY3Jm0gIKJLiJplhDHyv/h9q1PMUCrtz2/Bfe2CXO6GsUfCabxvEGBBvGLYQoSIhlcNW0rHcZlh1X6kEbgkEboWCAno638Z9pcQ17jDAklDXd9rbEdS8qGCSYgzqN2mzj7iZwKm94zue8scqyxMXFGcbHY+zv7P/xPM0/HmX5R0xUEcFrEmAdNGIeTca/e/dzr+Dk/AQffPABTk/PcXEx+1qWj38vzEkQ2pybq4ttm44nD7MkPZIkYLQGAcjSEfb2buDg8Ojtvb0b/8DlSHYWSmtdyJRgX1SlxdS9F2tXkGI8N+FTiQ0Jjg1c9ZyoA70ZtXEn0w4xZ9sQ+1quK+GLn/hcZrbJENlJdep0jE4+inW0Xvfo0kcBVaLkQorkVIrkNFXZQyWSM208F67Ley6TZBhTMDHbEbPNyN3PMEDs7ytIXbKv8kOxBRCrGoh44oewL3mrWRtpbEEkvZDmAhXjReAIOIXw4TgEDbaA8Va4oihwfn6O45PHb+7t7L9e6fKOi1CxOQNsjZkoIWoWRqosfXD33r2/+eCTT3759975IS7OznF+cvrN3Z2938zzydskqPbuGYakWHBpb2dJ/nGeZZ+MsvxIkIsslplEkmS4ffQK9vcO/4vxePo9azixtT4gIiOJNAhga0BwmTABwDKDWDT+HbDsi7e0KVLDnMbthWobtuXS64S5dfrXPuxYp5+NtQYx5/XWrYKItDHpw0oVr0opZ1pXRyG1lEs8bTPLq7kd4jFTEwS58vvK3zFkCHi2DxeaYyxBtOqcwhwUdCF1qACRbjB2HABZlxUuz89wen7yJ0aT8e/t7MgLqdQpjJkyiwJw+XmzLPsY+3vf3t/f/+WdnT1UVYXT01PcvH30xnTXTBNvgrfWyQlEZNI0fZhl2YNxln89ERKCgVRlmE6n2N+/8Tvjnd3f6KoXWTYOYI0gO/TW0FQduqptTbxdQnxWffB2bYUohUvPj6hG8DaGBX9eFPwpCk/E58aYiUrEMkmSY62zBzEXNkbvkXU5zzqmZgvJDMHNPDThR4qZ0ORr8Mn2BsbS+WxaMCCSS9TXNgvPkhHnipCyJfrYCNJwKhhcXl7i7PT41Z3p9L+T56P38iw5cbng9B6RnFvDMlHycjrd/e7h4a0Pb9++/erFxQU+/fQB7tx75Sf2buz/mlTqVClVkC/YLYS8UERayeQkyUc+OR4hTVPs7Oxgf3//25N8dN/PlwTbERFp8onCfVBQAxZs45G2PlXAUNsoWaMHGzrzvEVZpuu0ISFum3usO6fPLYO6i4gafXDjeSbSR0qpc631XpIkx3XtkqBUVXVkjN7V2kxdrQqbBf8AhxddbYqhHSBoA3pjXbHCxb/FhB44qSNU0UCGuI84FVL4L4RAk2fBWhTlAhcXZ7i4uPGN6c7+f52lo/fds6tzWE6N1buSOEmS5GS6t/+rr7zyyl+ezy9xenqMi8vzz5XLW1/IstF7LOXcZX31/g6AEUpeBKtgkiTIsgzjfIRRln9E3suPwRL9nYva51+3uPuwa6ht5LwBDzvCarGxJzTBL8Dftw8hIiy5VndMjbGia1wYgi2BGxBRcw9B6kJIl9JTKXWeJMmJtTZTqnpkTH1Q12aqdXU75ACu6/rQWvcJiJoRqv80ESBNoun4BYXvMcHFx8I1myBH3Bz8dWmW+hEdRARGCN68xMnJk1vTye7PTUbj30/S/ANrSbMQBSxVDFEz5OV0Z+e37r36uT/+0ScfvfrgwQNcnp1jNr/8+mRn+k8UJ0+kFOfa2kQwWaf2UudCJixUSkk+QnDYkVLOJYnaGE7RQAebNfAqPAqtN/9uoxN/CpPtdlqH+Jzr6m6HMPAQEW+rcls31hCh0f53+kwfTaGSJDk2xkx9AusDVzKgeE1KOdda7wFkrDUTsE3YlbCSbuykmE3m/G4NwMJXRV/9jHWcfvwdTUUrsLX5v2LHnv41LhGeyxUeiHo2m+H4+Bij0eS/Ox6P3zk4vP1pSKHqNDLEurajPB+9d/PW0X+8u7/3bzx48ABnZyc4Pzn91o0bN341ydJPJJyrJdAkOzTMTETkSgh4zzlJogbZzGWND4wkyjvcvJhhIu0+z3ou/NQC2zqCHNqut+mvT4jrhDjyaffXndu5rqmd25heVwpZx+N0YyBDQEUESEVaCpsraR8lytW1SNP0UcjE7gu3HDhO7DCxbeLfzIQJxiXwcFWHmk9BhtlIFgRrhdcWuP9sCUzuP5xXA0DCBdSSAAkB6zmsQHC2a54BLjzfEa+pNQQ5N8vZzOHYNE3/tdFo/O5ksvPbQiRPXPQ0y0qbXKr00529vV8/vHn739jdf4DZbIZHjz7Fwa2b30hHo3cSNXofflSJECVBLqx10RGCFFKpkKbpIwA+B4QnXIaAL97isK2PvrZhwwxCqLNOkv8/QFv+v/v7hWobrku4254XvOFibcLQuUQQscTbG1vj50vUZDDuVMwM1wUrU5Ikx6lNH2pT3Q45g0MBF2PqwyDYNaWzCNa5U7KKaldk/jO3NiSstpm1OjOGIUQFrbWzQnmdrsO2Bi68SHu1WeCwLvXRkFVP1y4D5eXlOeq6xsnJCaRMxrs7+3+WmdX+jVv/qTFktNa7Wut9pdKHeTb+4Y0bh+8fHt56/eThQ5yfn+Li4uxn9/Zv/FecmwkJKtmSsUDAv41VUSmFTCXnrQqzqQSa9HXoMUyKj8WahmfCvE/TngYqxFwzJhqOcojF/TaQqcW8g7WJQ47e/uLo4uTO2HuOPi6mre3b5kRkEpV9kiinNkoSvZtl2YMO0fqXZplFlPRk12W2MWOwqEA2tZpT5kC8bRFDn0+i60PMmsACIOv0we6TA8wJaQH8d68ZsJkxZnp6evLG+cUpTk6e4Pj4MX7vnbd/8fUvfPF2kmQPRvnkd5MkOTHGTN2OwfLm4dHfeOXeq//mycPHOD09xcXFxWSxmL+VjyY/gFTHiUpOgNa5nZmhSCBNcyiVPgJE2Tyr82MQbpezuVtYfo7RBqC6ReC80SqjUeqyMdL0WxBkP5NeZaH1CTd87xPq88TUcetHccTzSOTC8Jnl3Je7ajh5OEebtgxW+N19Jw3YnABqCN22BOv0zC3x+uvjBe5C3EUbTR2INpQECM9Y1/Xh7u7uN4+Pp39aCDE9PT3F48ePIYT4I3k++h8eHd3997N8/Htp6uphWGvzvb29f3Tv3it//4e/+/YvuqySp7hxdvazu3sHfz9Ls/vMNmfjYIBwJQBin47VVLYM0TvWEUIDxzXGRYZUVYG6rmGNWUnQEl//woh3EwdeebjuwPpEdQ1IQZ0gTYJc+C+9vl1V9aCdaNtwvt52bGEsNuviZWeoEESLKAWUUWt0MZ54s/ZvVqHeW6jFwcxSkqgH50MEFabjtkHt16gAfdFCJpeLYXd39zu7u7vfHY/Hf/HjBx/+5IcffohPP/0URVH82a+89dXbr7zyuX9nOt39LkOUWuu90Wjy9u7u/rfzyfgXZ7MLnJ+f4+zs7IsHNy9+Sqn0YZKIB1KJEmQzEs7/IjgOBacnN02c+qwOOTMgncOuN5QSQm4hl9eYUBuNZVm4qp3l0meR7KoP47aCB7cllm3bVZxxEyFfFwsDFGOq57Iw+4vQfW4WVv0zx1oRz9VD0UEAkHFFTMNMGsLVnmhKSnHX6N9AJF+1Pq7MTkQa7IsOgiUzaRIuyJQofTweT793dHQHWZY9IKI/8/DhQxwfH+P333v3Z4wxk9de+/y/PRpP/1shRJll2YO9vb3fODo6wnJ2ifPzc5ycnOD2bPa1yXjnn6Rp+khA1AJkyUVWS5UISEmAFGvDrVpB2jstIdZnG5TlErPZJWbzS1RVhYRUo7Megg+DN3jeBBy3eLKfF4Ft31qusM2941rIoTn5yBk3gothv8/+ZzufXe1GCzO8oSN4yYV7RXU1un2656i8wxFBLuJ5dV51pI3lu84RCSyEvJxO9n99NJr8IM9H74/yyV/54P3fx/u//x5OT0//SF3X/8cvfvFL/9bOzt5vCEl1ksjZK6+88u7s/OzN3/vh7+P09BSnp6d/fHdn/9d3Jru/RYIFESsJllIgDl8qwaJiggl5kdu8xAECBS4anPIF6lpjPp9jNpthsVg4TJt0Q4wa3bj//lJi2IYWw9Oq1K46bwgnbxpXH6P1+xr6z8HsuWFcgQlsGkcwU1Nrsu5ELLd4uFsvedsmJNUgX8yG5FwIdS5FcnpwcPPvvPLK5/6DL37xTezv76MsS7z3/g9feeed3/s/PX788C8UxfytJElOjo6O/vrNo9uQicLl7ByPHz+WF5dn36rq4nOwnEl0LXsB8waiHUobFs1PEz2itcZiscBsdonFYoGqKsBsABpKA9u2l8b5tuXmmzj/0whm7pvzPaAW+8r+PRyxrB/zkODVFyTj84hIx/7Gvpc4CLJj1ubIMhf+dn2whO2P1dfoIK+uinaUIMwBrqKPtjYh5kzXZsrENUAmS8fv3bl99z/YmUx/ANj//fvvv48HH32Msiz3AfxvmG22v7//7d3d3e8cHBw82Nvbuzefz3F6fIKLs/NvXUzPf5P2dn6bhEs6H3PGZvyEVa+iZpBtcKrWGmVZYjab4fLyEkVRgK3ppAYAejncfFsh6xcJGULrbpnbnbfdNt9yxL72IOaCgYNe1Z+X/jteZR7jlf156o/VSdmiagn3eq0RwjB4r3WBru0zCaqYzdQJjsmJ+91ZDmttxkImT8bj6fdef/2L//Zbb711cffuXdR1jffe/+H+D3//nf/tk+NHv8zMamdn7zfu3LmDLMtweXmB09OT/OLi7GfDGEHURD0EF0eQTYkhmtK5zcDJWAJCOVaikE2nxHK5cNknbe24brQoeI2lrcPlLGCG1MJX5Sxbl8dh3XVDL37db/Gxla25rTXhCFbIy/C38z8d8MAnaoqEM/qeM/IiGpOUQuiY07a/dbHwuoXlBK5263RGC5ZA69zjn8/48aQx5/a+C77mBFYzd7p4O8nEVejfEVSgI1EIOEONlHLOsAlJsbBgAsMImTzZv3Hzb4NEYZn+5//s/vs3T09P8fCTTyFJ/Otsyagk++jenVfK+eUse/z4Mc5Oj3G6t/dzt27f/Nua9cQSXFSEFD4K2vnEEOwoYHmCXBKRtmBFYJCQMKwhARijcTm/wMX8FFW9gDEaiYqScke5z6yzx0AAnx097/MS3rhXGGWb+63TdvS39W1b91nWY77+vf2R51SwvHePIY7EZA3YCBLL3d39b3v/3P/pe+//8I9cnl/gvffeg2Xxvzg4OPjVg4P9bx8d3fqF2ewCRbHA+fkxFouLbxDJORMsCSGCEEVEWjCUN0h4i2j8nMLXwCZorVHVBcqyRF3X0LrynDXAhc3J9j4TxLuuPQ2E2ZbgrsPhB87rEHZ/8TX9oFul3Y9wtW9XyRLg3pgIvUUdtuF2UTgByWFrYqkJkAQ7BgOQYuEke2cpbIfgvNydP3N9SJALr0r7D7XWew/kg88fHx/j4aefoFgu/vjd24cPUiWwMxnBWovl/BKX56e/kKWj9wlWCPI5Lz3xsqBCkJxRqFLPfndhURHIY16Bsiyb/3VdR3l8h1VjISN6aJ8Z4t2G+z4th6au2Xct0cXHAYCAFa3CprH5/rd+hpbIsTYU66rmVGzDHJsYYp3gRETae8ZpAtWCSE+nu9995ZXP/TtCyH/ZGPOVJ48fYz6/hKT6njE1RqMMy+USZbnE2dnJ4XS8c8i6bgjKEZwot9hxwIxONqDgIRcEuSHi7bcr/Hlfbn7ebVRqQwS3bosfghBDXHPT/dw526uptl2EnQONUGecDGLZ5w0O/fX1zT0ObNnnnrAjAmlYUUFQxTBjAhmvV9WxnhsACC7qmpmVtiyI1cXO9Mav4Y66tNb+VaOrN87OTvDgwUeQSoCNRVUWSNMUZbGEi2xlEFsoajkvBFXwnJdZ7zmVRL9GHzXE22S+XMN113Hil8Z5rxLKnrUNEOVa/NgISGsc3Js/njJS5Dpqwafp/6r+CKjgigI6Sx+1lsFY6xLvAETCEHFCRPPpdPq9O3fu/TVdV/+WtXpy/PgTL3269FO21rg4PQPtuRwNlp0PQuIzAfaMJp2oa0eEbSRIXLMt5rjMq9kj+00B22d9XNcCh962nyFh6UfRrhbKXKXLwLmuMHOvXRChtVu4NxM7WKIA41wvWfrq7b48ARn/Jpvayx2BVPhYPkuubJXz5XARugDAlpz2gYmJSHMIkPO/J0n2wKkCHWc3bBVbzoWQF9OdvX9475XP/V8szF+t6kJcnB3j4vICWmtkKsF0MsIlMZI0RV2XECrpOuYIeQErRwCYWNQOC7OC9yoLsCE415N37dyEefvtM4N5n2fbRuMQn7tBb/o0HmtNfyvjaLbOkPchGEvWO95vXAxrDDrheMskBtRsRMZhXhtK7AbroasepNTF7u7+t4/q6vZyPvtXmA0WiwVMWWNWzHBxcQFrNVKTQVcGqUrAgkoGmKRYxM8ecWH/3CHlEzf+6I54nRN9sNYNjLnzt3pWrrupxZP7lJqDYf3pGuHoOkR7nfsHQtgg4PXxnOfCgQs5L7Aw9TFBhmQnQsh58zdzJgRrAzslIkNKuPrM2uwCzqzMzEokroQrNXChP9ei8AtD+t8NATLU5ggLh8hlmg/XGlMfAkCisk/29vZ//Y0v/qESwP+sWlb4ZP4RmAmXsxms1chql2wvxQjaVBkzK0vQgsibudU5G0QpU62v2dZmjafIPTKkP/VjGUyZJUEg/ueI824r7ffb0+hy/f2u1AMH90CO7hNbCyWJus9hiMiAoJmYpHCFAOPFE59rjJn6a6JUV6sm6zWCa7sgYddoO0SZJuN3d3fl7M7dV9+sKv0v1nWN0+MnqCoN5iVqo5GNRshC9nayCXn/BguxELDjGGfHRt3YYuYc7K/HewZf9PPSMrwsTNt/YVcZIJ72HkPcdxtuTwxBILZgil+kZVYgGIryUDhsaDO2rNjaVBszBnPC7BzWO2NhiG7pAQBEAlK4v5s+Yy0DCxdwzCkIYHDapq0K/h+kmUlrY1MS8iLLx5dHR3f+IwAoy/Jf1Frj+PEjaF2h1iUsgPG0hDF142kXxsSQFyQ4RcjCCaCpxTyQVYh85qA/8Jh3CyFpnTfYUxsgQnMC0OZxXaHR0EMakN6Cco41DNm6V9rcWlaW9U5V1Qe1Lu+ygfCRFnl7rc1gIYWkWpCT7oUQJUmxUCp92ERXkLoQoi1L5YJA29i8rvm7OzfW2oyYDDNsmo1+//Dw5n9+fufo56vlQiwWMyy9I41MkiZru9Z6j9lMBCVPVubDCajh2RF/JwphtXHb7PT4mSZe4OkNE5v6C99fgKqqZ562GRDpiIlKRA7zXsAGg5WFGVltdo2tb1RVdVTX9UGlyzt1XR1p7cOCtGmq3jsdrlyQYCFIXZAvt+XyTqSPhJIXSsilUumjJEmOlVLnJMSSSM4JqwvcwZnucUmittbmhq1SChiNRu/dPLz9n9SL4r9/fnGKerlEuZhDVxWqooQuKxit98ly7qqN+iI0zPD54oSvcxHft/keuK3tZc6Jv8ftM0+8f1BahGllLLUD7RYaBDePe0PM28QYM9G6Oqqr6shV9Czv1XV5r9LVTVcY0UyYzYQNmipAgXOFFx6EGymllSr9VEo5z5L0SZIkx1mW38+y7IFKk8dKpo+USh8JIUpjNmQaYrKE4Exux8xUSinnOzs7v13cPPzKwfHBW5enx7i8PEdVVVgulyiKAmVZvuLrqq1LF4u2dFcQ1NpSXs2zUZuIrze+5rNDvC/Torbu4V5220bwetoWomc9HpXMdmqtzWutd4xxeSAc4eo9barbdV0fVFV1VJfVXa3rg0rXN+q6lMwMEk6tZFl38GB/6yUiIUjdIyIkSr2plKrSJP8wSZKTNM/fz7LsQZ6Nf5im6UMfqGlCvQm2LsrXYXCGq+HpBTBrRxpMoRDLwY2bb53vP8HZ2QnYGFTLCst5gWKx/JKp9YFKW63IpljJPu7tt3UETC8yAPMPYtuWkK9jKo6ukSHHw7IoXg2EGqrXh6jhuq4PTV3vWmt90mhG2GpJsM9t695onI28iyGdtbmEhBAilXL+RaXUF5M0/4pLCl3ey7Lswe7O/q9LmRwL4UOLBCs2iDFwQgCEFIU2ehdMVZKkDyeTnd/e29v7C7v7+1mWjVAWM89956iqKjO2vkFsx0QhUHQYArTjNWCYlSrvIcXpurZpRVybM16Hc1+n7+vi3usKZ9SzjjW4so3BasofBCk//jsId9yz3xsLDkX86ro+LMrFl+bz+VuLxeLLVeVyn7nkI50cDQABJF0qKBf6Lf2LZsRCuJRe0T9QZdM1hmENXdcoa4CWy8liMfvqYrF4M8/z+8vl8o3pdPq9yWj6TxOVfSKcmg6WXMZ4ArG1NmODBCxKY20iJc2FVGfTvf1fPTi4+UvTvV1U9QJVXWA2P8eyuERZLt4cjce/p1R+3xrIMCnWaTpc/t2Omgw+uz8DwrrqQN6DjCw3clsMk4A1xPu8BZk/aK2/WNbNR13Xh62aatVzTblkHpO6rm4vl8s3ZvOLb8zn87eKonjNcVvTySrpcWuTidFa3ST1CJ8dzoUW9/bLBgSijq+zVqPWJaqqyuZz9eZisXizKJZv1DvV3el09zt5Nv6hNyTkQKhbYTPAEbMFk9a2JJLz6XT3uzu7+790cHCAxewMFxcutX+xuESxvPwpPd35HYHkjEE1d2L+GGDjTcO6G97TE+auan9giHRAvzqUBWctN99mQVLXtLsS09b05TmyTNSp79tHbtgsrrZp2WZVVbw2n8+/MpvNvjpfXH69KIrXjNEZEUFKObgvxoaM6NjAiS4PMEdCXPwZMsvEFixrLWpdotbOj3a5XH51MVv82O7u/K29vRu/Oh6P302S5FiSLEztCm6zLwkGVzM3I9gsy7IHOzs73795eOurx48e4vz8HEVRhOjfN8uyeC1Ro/eJ5FxEgb5EAgbdyp/9ZxvSAQ+1tebX58F9NxHb07RNfTwv4a8PIfotaAoAZ+EKXFJIMFHItu4Sh1R1fWM2m33t4uLipxfL2R/2moPM5/W66PXbscC5v1ehwLrPqJ+VY2GrDdlnAtEUhctMUxWlKsvyZ6qqOtrd3f3OdLr73TzP7wtBlpiMZedUToIqY8yEYHMlRDkaTX6wv7//1Z2dHRyfJCjLEvPLGYrF7M2yKD4/yqo7QiZPnJmclRDqHLCuoAobuCIwGiFhNng4X+/Qc24U2J6VGAY4x0vXLvStbdddkETed4Dgtz5njgXc8wgJSwQWgmoh3D2stXldV7erqjq6nM++4rnu17SudyONgA+fd95c8YK5iuMELtp5ySzhjdBOb0yrgtwK5GBGmilYAxTlAkVRYLlcvLFYzN84PKwP9/f3v50l+UdSyjkxC2P0DbCcMbNkC4IQZZrm96fT3cu9vRs7k/EOLhdzzOdzrzZbfLnMxz9UykxAciakk9qExOC4HMRhV49YDJuQ++0zF/r+Iu67joCHCLp3fkiAK1fOJ5sqpc6dRcxMqsolzKuq6mi5XL6+XC7fmC8XX6yq8l5d15MAE0IfzmehvW/EeddI5Ou5UjT2Vgjq5QLrh443vxO7BHfWoqyWODvX0Fr/4mIxf+vmwc3/33g6+X6SZA8AZ862liVZTo0xpIQs8nz8zt7e/k/t7u5i5iOAl/MZ6mL5pq7KV7XWe0SkZaJOk4SlBMFaA4BhWTe4NyTHbrPBryfaMA8vjHiJSAePtevqj5/2uk1jiQl42+s4mE4JhgGiYIEim1JTh8KlOS3L4rWicP8Xi8WXi6J4TVuTO3WPi9kiYunYZHgxDTGuCG6AS8ax7gX2tQsdGEFdgl2tLB9/Z1gYMIWChBWMMajq4hVr7Z/d1/uHOzu735WJOnVO5g7WGGNTwUCSJCc7OzvY3d3HkydPUFUVLi4uMF9cvjmd7r5mQAUzK6XUeZrUt6QS/7llRlVVTeGXkMI1LCjbIVyL1Qqorv2BEdiG2nWgyCbYwFdEHXeuI5u6cqZmUpbVa8boveVy+fpsNvvacrl8wyeenhpjwNQGFDK3mcyjMYX+Vz43cZ2+ELbye/R96B7xVt0KdwAgmiqa3snmptb6T2trRpPJ5O00zR5IUpckRMEwY8sslEwfjUYj5HkOpRTKssDl7ALzywvUN27eM4ZVbU0mZXJcJ/WhlA4/lNUSxtQwpm4wb3gmZqfi68zDAAGrmLv1fXtflsXtulwxJqahbX/db/3Wv98mRx9mVj5DTW2MmVR1eacqyleXy8Wbs9nsa0W5+FJVVWOt27JSRF2zp+8rfo6hZ2vOi4ksEGL8v9liYfxW3PYRS/Jdjrsq4cd/k4fPla6hLy+hjUkszC9Zq/d2JnvfyTLxHrHQxpqp9HMshMBkMkGSJFgulzg/OcXF4QXKavkFsKisMRNdVvcKQSX5JCXMBsvlsi1RYGswnBO6MZvhURjrj5zzPo1WozEWPKOTTUiOvK7FXlxuu3QeX1VdvLpcLr58eX7xR11B7sWXtNaCeTW31iYuuo54N2HVuDV+DaAVYh8izhhGXMXliRxBFeUC5xcAw3yTDeTODsssyT8mIq3r+rYFk1Dp4zzPb00mE8xmM8xmM1ycnaIqlp8XKjmzBqKu613NbhFaX5LLZXkPFsSeioy7Zbv8G0EoQg5cQbzPG3s+zzbENXlAP3pFHxuDNH1hFekIFzDGCWTzxfyt2ezyJy5nlz9e1+WB1m4o0nmrAgCsZVeN3f8D4PSyvvUFsMBBOy+Lu8ILCQbY6W8FCcCXmg/V0tcTp9OrwjppHuw+qQnQ657vmiuxWtclLi99hC+LnxZCFDSGdIm1W9dKmSYYj8dQSjnivbjAYrHAeDzeZxK61iUq43algGmNMSvPbK2FpOEF6Fobyf/MDtpR5y+diz+rPjpOhDxE+M6xxJV0NaY+LMvylfni8sdns8ufmM/nb2ldHXQjX9sXEH+2xLjexh8k/y736Z5ne2nuYzzdnDMAFxpC6B1vzkPPXOuz1Qghmwjf5XKOS6kgpfwWmJPxePyuItEwDCkUxuMpsizD6ek5lsslLi8vXaX6LG+IVQgB9mOyrAfnwVL8DC5vWfj9SvNwvz0rFt6Wg/fvcx2B7GnaEOHH9wsO4Frr3bJ0Qtl8cfn15XLxZlmWt611p5II3KslWHd9Tz2F4SKCodol2x7xRlymT4gBogSY0uXiZsA03Bajjvty93dJQOI15hZFuL+F1hXm80sAELD00wB8omozISkWKk0wmk6QT6YgeoLlssDp2QnGkxFUmqgwJrdIqWddY3cvfztLm7UsoT0Tt3we3PZZuOcmwW3b6wOxkotEKMJxZlcwpK7Le2VZvrJYzr46m8++tlwu3vRONQ2nJUKzLXeIdyU0YI2A1uO4DUygYWIPIeNKuUfuE3BMsPHf/cXR/Kf1ljohABDDskVVF8AcUCKRSZK8QcQqSVzgaJIkyPMc0+kUeZ6jrmucnZ3h4OAAo/Gkez9g5bmYGdbEFT77iX66C1kI8aMV2PqCV//VPo324br3j4kXcCZfrfWuMWZaVcVrZbl8Y7lcvr4s5j/mVGHV7aBQB4Iqqq/8dy9AhNrAEdbtE2RQbXUJKpRzkp3FgOg8992EbOT+7zCuYSsWesTbcL+2jkbnPk5Aasfu0pFWmC8XSLL0NpNNxpTfBxhSSp2mqZpMJphOpyiKAicnJzg6uoXd3V0wbPtcgkCCOvTZGiqARMjBOmz99iPXNjxLe1bOH3N9dlavrK7Le0VRvOYiGpZvFOXiS4FotdaT8FK75lkBIgsh2wiB4I8LANzzqF7V1faxqwB6ODR65uYlG18tJyRi7nOzFfy7gXgbzUWktWjHECAFQxunB57PJQB7QylRJEpUpOS5SpPD0WiEfDzGsiydsWI+R1VVbszGuntZALInrHKrEuwv7vgzbsoCJmDRPiZdl9NhWwxLPTfBlf6c3mOtxG97hbtFVP94sHGkPaDgWGOzocRvMccNFXiKonhtNrv4xmw2+1pZLV+vy/Jz1jp/W22qhBGEJBVBBoboGQKCH26oh8JideuPvzMLCHKCirXWGTO8f0JsLg3aAm6I0rhjxnacbozX5RJsq/9lt/UzOwtW3+rW6qbbZxGQsNpzSvLFu2GhbY1FMYeUhCSRd/MsgRBCZ2mOJM2wd2MfFxcX0EuN2WyB87MLjMdNeY3uPBDBssPdFgzBWBlXs9hF1+jyB5rzPkvrwBVmVZblvdns4hvn5+c/M5vNvlpWy7tsDIRsV32bAMOZhkOxPvIlsDxWFs0EQ/Sd3PtjaD4DJ25flmzi1ZpzTFcYNKZVjQXjiCOwgHFNhxAaVZqX/GNIIoRo0y75RoI6HDG+d107HXCSSkgxRpIkioiQpinG4zFGkzEuLs+D2yXyPHcCJgDNNqh2V6HKgOUwnqeOtuFF6nD5ucWGbdkP+fRJTNYJ9leXDSDvwlgUxWvzucO3VVUdaa3d5m0FSMnAmcqYY0vpo2PhhBaO3CUBp+mK7xV/9sYhA5eNt3rLva1VOCIKWRWZE09cursQgm+Dtl0BMlL6W2NgI+4WW/GaY6xh2cJGCyvcQ2uLomBXBchbEhMhkWUZJpMJRqMRhBBOZTa7wHRngtSrzEIfQgiICCo4Ye5qrBvaP1ecd1XA69VEGGge6+bB2pYk2QMh1Lm1oz2CHTHbzDAL5k5OL+fD62UZgqtkueke8efAuI1/gTIQEtDNWuCI0r1oKaVPoS88B0YDN5gZJnBY0+O8ESd3elbuEGTM+QGsVJWPVXOB2y+XSyjhF3eaQUqJPM+RZRnyPEdVVZjNZijLEkmadXYZ/+zuvxtgo+Nts6OvesiFptyMcNem+dLaVdlmnpJzX/N5iOQsSbIH4zGrPM/vs6CC2UxZm71al3eLZXVU6/KetTZzREsmYOWr+ubI+NHfiQSRjc4T1B5vtA1ugGHbpg4GbomXGgOAS/zhPbUigrbWNvpkf792m4bfvgkg4UtaEhrVVbDg9eENM6OuayyXywZSKaUatVkg3uVyibquwdYAwiUXoei+rcxA3h/Eq/78XAzM6T9fmPdZjBlKqYvxePxOnuf3iUgzUQWyqanqo6JYvKnk/CvLpZzXdX1oWe8CXUciWpPaxePftcGgzN1F1tEMIMKDkXaizykD8QZOCLT6ZW16hgoe8CFAy/1EEIh6XC6+ZwwvGI47l2XZ4cpSSozHY4zHYxRFgaIoUFXO1VKRgoQnXG4FxaFs6EMahvi3JsFE95fNnOvZcfLzyeZ4tXm6W7uhOY876TcNEaosVRdEpEmAg1aEE/MgSZLjJMkepOnsa4vF4s2iXLypdX1orc2kbCIgACJLLCpEKZOEsEkMGQSR9QTdme+YiGNCaU9wQbfBT5dh4PNB+Jev4DQchCTxIT/kctYE7uyI3GNqMg1HDioxx0l9zJvpwgeiGA8T4i2dvfBXlmWDx8dZ3mDfs7OzRmirqgpSSpAgWLYgEhBoiTcQcEzIRD6SOArMDL8pDKuqVr0gnq6tu37bfrcPJb363FAZ0wBkedWH1zKzYANYL/gppc6IRpWUyUMhxBkgnhhjKmvtq9aasVscNkO7mNlvp4GAlf9NEZEEczLETaJjFHM77v3e106w1zbEhBhevpQSaZpGhGsa52/LXX1x3xIXmlJqpc8wnv4uUNd1AyUSj4HH4zGklN5H2MXLpWkKKZTXZHf7GvrftlV+upF4N7DfrTjn+usdpyGIGlivlbC0cp9BUdRfH9eTc9G91PNgjnYYigoJBmkf7Y8VM8AWTBCFFMrm+fgdFnQBiTNxiR9fLOavW2ul60cYtxggyMenWWtTcrMvCVAMSN6wY8VjsdYmfbVQTLjWwKnJvEeWZdvR2xJJKCVBVDdEGowZxhhoU0Ep1VTgaaMZbKewSSDI2M2z/e6iQ4QQkB6Hl2XZgRppniHNE8gFecPGJSaTUavdEM4qqIREIhVsyo3ZO9Qyju8ZcH7o3+03A/SwbpKfZ+PWOXNbTjw4LlrNxhgIeSUJyzb3Z2YiImMtmEiUQsAmlNYQYg6ghLEawMlisbgHNGqumhjCGJMxd5OXAJCeENdFJIt48RCRhDO7WQCw1opAhDGRGttqAwKRBRjAzA3njK8TQkBINAQdsLLjyrqTal9KuRaHMzOkFM04wn2KovAEKJEkCbIsQ5IkTi9cFM4qyNz2jS7uBdAxeTs+N8wGHeddxbgvhXhXQjv62Hu1rWXmRGTt6iLon7+2f2YWLDoYmjRbt3kRMwkqlVB6PB7ft9YaSzgzms+rurhhrU0AKoUgttaO2MEDi1Ciym2nInrxIeNOGE9/nCLABmut6hOgvxbCJ5wk2YUTwQxsfX6E1UlLIIgBVBFuFrBWdThxWAT9RRO0Ho0OmdvtP0CTNE1AaYokSZoIi2AqVkpBpYnzeYazrgVY4jh5AikSkFCh0mtkXWufJnDel0OsV7dmHO7F8kbOOdD6xHm1W1d0P+5dHwl5sNYmQggtSC3ybPwAQEGWLmczemWxWBwYGEEu28258GyDGbGeeUUoE648bIe1+N3AX8+CmWmI83UEmygSwanEguXN+/+uwZFxyvxYBddyX9ODFe04OteiHVM4V2tC6bf5NE2xWCxCFkkkSeIhQdDxdi2YATZ0NBBMICE7z69A/KxC2fNrrhp4u5zdwoRot3+/T3ZZtl0TXboFJ++3zvlCOEzu9Pk6tdaSEEInSXohhCgkqADswhhzVFbLHa21ICImweShhxuGI1AKmgbyWJydh08QdIiZhXOQhGBmckEPJGLC7QtKQVfb9Y9txu85MOAu8U42TtUKNgRrGW69eH0rRddFkRmBoAOHjP8LtPcPbpphESilkGUJiBi21qiWBeosQ5ZlTqeMrkouYPN+1fcO/icJC7FWYHvpjfrCVe/n3t/Pfadw9+92a61tpBMiWQFWsAeVUqoiz8fHAApmuri4wEFVLsfWWkF+xyAi9kRJEb5m1x9x7yGCHooCx/W4irpqq66PQegweo5mtijiiH2u2yf0oQVC7cJqsHGAD3VdA0BDwIHYsizzhpIapi5dfbbElbnSWmOxWCAbjxxO772DeGG0qjOJkC2qP65+EON1VFPPra0SbiCaFW3Buh44nNDpa3V+1jbHwTq+CAQYr7oS7HYEYa0NhMlEUhVpPq53gYKIL+czmpRlkRpbS2utaDhsd17Zr5LOvSJ40BCxfyBQk0zd+Vb2hDuAJQQJMBkvxYdQ+55jT+86magGI/cxNQAI2YUoQVsRO/UwMygF0jRttvs0TVHXFcolQ0qCrhzuZWMwX1xiXE5R13VTdFAwQTrzHhIhO5AhXrT9vzvahrDKXmYb0nuifbFXDsY9UKsSfdbxrBAGBHuC8oRohCNmd46UymTZSDNzAeZLAElRsLSsiXupkf3kd/KUBoIdwLW0snhBjR6476Tef4aggei/z1j1FRx8AlSIn98JjKZzvZQSghQEtT4T+v/f3bVtt5Er141Ld7Mp2dL4rMwX5C0rj/nv/E/ec2ZsyxLvfQXyUCjcGk1RsjxzVuBFkyLRuG4UqgpVhWlCb0OdTdM4KiygJTCOPeZxwmazQX+5JJdl67rJqGk4rJBSE9Ut4wMACWy/552LBmHhZiNWjmFLv8fPl55bL8uTmhmIV1eOZTEjsd3Ky7Qb3JgsRQRP0W9F79Y5rJnvjMBEC95OxGqSik7qam7a+ztrxX9YyP+CUP/Z9ed/n8fx34QMarNIAKQbKa2YrIW2FloIOcHdX2EEJqlkJ+bpH/wsvVMeIYwqudizldhsZ7fSJDhOA5C6C7EqjAZ5hnXezoLLMgZSaszsGe1YA6Uqz+OO44hh6NAPI8Yp6IjruoLWGsJR4mmY0bZ36PsR42zF5XIh6j3NqOsa00h2ybKS0KpGVTV+8ZGglsaqgAIgDDSAP26d4Gvp76DapeQ7/aGJl0+6IRjDVEpBSotN0/6PEPa/lVLQlUR3PlMwjcxWgFPOx/IYsjevzCh06dn8t7iuXEcbPxebX+b8MOdjvraqKlBUnC02mw0qVcNai2GgkKaHw8EdQtC9FGRR1qBtGmhNbARH1OGTtq7rsNlsvYDHqj8GqFJlXjf++z1Oi4vBKw3orWXlz3zEAvBtfGP+28vnd6qBtnDrDVKqqkLdkOH1+XL0huJxfUTZAFoIqVGKsjw2ISI6kqjofExbcGMvgFa4MDhCLDUS9HvqhuQPMyRRzrZtcX9/j217j7ZtUVcVAIqlxmzC8ahwPp3QdWeM44i+7zBuNthutzCw2GwpJFTXddFxManNhIuUk2sxYnVgQnnfC954Aj6Cwv2d1Pr1upd8JSvpgfS0yZgZQgpoRffnGtvg5CTs2OqKX3ndJQr4OoHI4kJk/crLyvlgBnLM78ZeE3xCdn9/j0+fPmHbkmewjlyOiKqSBdnu+QUvO4Hz+YxhOGO49P5QoqooKMnxeHRUm+9tG6BkDa3riDVRjuct2zrw+y83ifz4Lfwtlb8Gzuu/J6AQ/j8g2s4oj0moBFGWC/aHF+x2z+i6DnVdo3H6TSVrfzxKZSy37GJ3RL5oWI40GaXN2BD/G9e59BHjvPHCqqoGbdvi0/0Dtu0WbbOFkgocDEWAPCeUkO5F+tmd3uF8OWIeyJpMCIG2bckXTklYS9Eo3aWDEHUFoaTT79YeuDnVNXzSZikO3LvBewso/0rg/lU8N9VDn1PlOjlRjmOP3f4ZT0/f8fXrH9jv9xjHEU3T0BZqDDat9NsiPb/0/M37U+JLr7UxLqeQo0jJmPJyuru7x3a7xd32DnVde0EvPm3jfjRN4983mw1Op3sc9y84n8mLAgAZpFuLaZrp/oquQ9O0qGo46tygqhrP7y6obtaXtZCfrw7MWwfxPYnl6StKoage+9P1+VL982XTg5iieapgDIbhjMNxhz///ANfv/6Bl+cn9D1J1uPYY5wH9yLVUaUbx0ZwX1KKvqbqWuvfApCGA0ibEDMt2UHSPs9mhp1NcEGfQ3yzeZpgZcqm0AmghaSTUa/r5cOKZlNB7zTOhyNm52cnpcQ0jC4S+wV3d58gpfQ2EKSOUxnVVcnYvFtgyzvsB+pK+pVUcY0v/FDBr9C9ABISpIaxx/G4w9PTd3z//hU/nr+jv5wTgxYDPgwgfrHdCH8UmlNBrn9tbNc0GEkZEZjTfGHBMbWdZ6KG7PFAKfirKVV5Khtv6dZa7xHBhwtt26KutRfmNtUGp9PBHRefMXQ9HWL0vXNf0tCK+F4CrnZ1ZX51OeU1EJB4fXW/Rbtwa97XAMbPqCyvyX6PSoyexWssbTHFoAgT7HhaF2tsBp/x00HY0J1wOuzw7ds3/POf/4v9/oXUTFJACEBK5RX6DN5hGDDeETvR1K2nWAEgQC4Y5mMTB6GTUmIRmQdsgaaSvgHB+osFytxdxxiDtj1hv39B27ZomhZ1XaN2lmIseHK7YeEdRK21gCQW4kE+kEPmsYHSLnj1uUfXDZicdzMLdFprMlT3HhW0GKwUsFJAIrATwP8z7+GPToHyBfBQlEMBISzmmSyvTqcDnn58w7dvXwm4Uw8h2J42hH/iFxuBG2PQ9z2aevR2rzyJvF1eIwSs0vJthfILDkAiFKYeFYPXtbIDJVt8sRA1zzOapvE6WvIIbv13ZHDT+PYykOMdREJAyQrthiipdi7y/YXUZVpraFV5qlvSLjDFzTUOgAOv8ZPjTmLwr3PoACwpdLDlv57/reLi+hYskgolXX+G2QzoujOeX57w9eufeHr6hmHsvMqHygymhgFAFM5+mgb0vUJXdZ6q1ZENbOCJl+f8VLabUMlGHGFbJ9NIYDYGZjaOwl48leV3BnF8RwS3sxt6aK1RX6hdTVV7rQl7CLMGhdrdLIxqrJ2hBJlFVo9fKJbDucMwTri/+4S2vUvsIgSIylqh6Jo5SdZuef9/mue9BoKP0DS8tnhyafxnFluZTWIVUsgTqB4JYS8vP/D9+zfsds/evUapwE/yc/xsrIpiKjyO5MDI/K8HsG68VZaf3AzAbL8b94MByC7ndIw7ePDyi49pS9FzYp7WeyVPs3+O27nZbMB3UjBrwWwAjYOFsSMJcVWFx8cv6LoBQijctVt8/vyIpmlJPQY6GLEIrFORErukiY55LpIayRT4JwBxi7Dxkentp2Sv58/7ED5bDGOH/f4F35++4ceP7+j6s9s6gy1sXk88+DEltu5Kp2kaIKVE3ysH2gDeGMCxy0zcRgbuMASKylJ9zNOOI7EH87wM/pF78cb9ni2FmJqtwWRmjPOEcZ7QjwPq7oLN5oKmadC2d9jYDTa1Y22cLYQWEkpVeHz4Aq1qbJoG2/Yedb2BFGHXCGyCaxfCUXGcNFOYa+qXWyf7tcn/O9O19t9C4WkiydBrmkecTgc8Pz/j+fkJl+4EIPCfMRUraREYtDklZptZtikALj5PfPrEAOZ2xVSYjmYvXo/a970/zWI9K8D1pyCN+xur6/JX3E/mkZmaN02DYZiIDdm0ZCKpKwghktO23377B2pdoa43UO535vGFZ5OW6r+CqkxCCODaFfHvBXEO4Ft1yLfU87oe+G2sR7kGYnBJJ0OU7Xw54+XlB348P+F0OhFfp4QfQwZV7G+2dhxMIOSrnChCOLvfAHJBuVNqmG7vxkxe5cU8LlHYwMfys6Ta4rIWLnQwBk5TstRpxy9uH9U7YZoMxnEmfnpLYGW+1kiyYKuVpsMJpaF1BRmp4IQQpLWQElJU/rKYlAgSIdFxA+jzx3sFrSncr6XX8t9C1T+CPaHtyp0owfh7yvb7PY7HPfr+AiWQUNBSG/Pj2Jz35c8MRgIclRPHV8jByCCOb1BnliReSOwpnLcprjsAMuXTrYU/VYtTbDROi4q0GZeLW0AD8bp3dyO22y02NQl6qmYtSDCykU5FZmUK1jWqK4SANlYAloO2BYohFZKgyKSMvl1AstbCxuCK8sooT97QeDDzlHlHLrQNeWC6aymuO86b6pOdslhJQAqYccLptMPu+Qmnwx7d6Yxaa7B1l6DwjC66ZBpbN+5bDlr6MwYN9YZ38+BTxre78xDEvmt80yZAFm4UJlVKCeN2VMHtMfnYMwVma7V4mEXGXoho0aQsEgOY2mrRdTMqrXGcDYaux8P9J1SfH516rIJUlStbwUqyXZCuHqEkjSeWBkaQdFKoiSFehm+gAX4/vyoK4CrlWdb5a9V0Jer4Wn6mhH3f43Q+YL/f4Xw+wmJOlObWUzb2YlqyQTGAS2DmFI9NEM7CTZq5jYHNrr3ifJZWRNpPkdfBPGbqsbu2a3D/OLgfLyI+EZMSUEpAWklH48PFhYGiANO5nxqkhhS0WD1whUhYhiXrAOhpmlCpoDHjbaY0qWtBBrhjP6OZiAfrZ8t7rZ7881pe9m6VFhhdOM/D4YDdbudjc7FgQTsNXAA5Q7gtsDXXwMupJOS5XxYAzyl68gLdUASTARv5QgknWiVtRtCKzABiFWKwAWEenZ81xkAr7QHOhknb7dbrieOIOwTilK0S5vqhhe77EbIhRTef2KyxktcA9RFAy0H8kQC+pZwSBYQzaOn7C06nAw6Hg6e6QVhKtQsCKIKytHgWW+JKuziOQqyXjcenxI5weTH7AsD7sQYBjo3BdeIJzHkClU/nI9gmz8niYFamn3onsLV4ePgNDw8PaNu2GPOMQFnmbUtUFwD0OI7Y1FU4Y7OWzvAROb/kvC6QuL++NbhvbJtgrb36/EdQ9LeUm0yOM6QZpgHH4x67/TOOxwPGcYTSPKBmARaO723NElhx/Ws7HKfYcCY+9Mh1vJbCP/h73qQTsoxZUmZXOQBEdhQq82QIRjjMa8dCYoj5OyVtiu/F4PdNs8Xjp0f89vnB30+8JoRxfF4KcoElaKULjer+1NKT6vIE/ire81eX/dZUaouUCLc/HnfY7V5wuZycVy1tsya6YSfexvMTNk4xaHOeMm7LGkUNbYvCLa3IJgymBXhtoMgs6XO7GIQpGMn6jfXQsTYkxwoDXEKhqTf49OkTHh8f8fBABjplk8eUHWCyWKK68WfdVLV/QBgKnhYbfMSpxMDDVZVTUN4+446tpVw5F8SIn0tr4PAOFv7YdyahJhNk5nnGMJ6dR8QLjscjUV2lwHxeerkzU7wyC7I2CfEusFR3lfniGPw8YvF3RWHYphQvAEhlQKJ9lwUzpsLBtw2YZwElw3UCsNZ7GmulUFcbPH5+xJeHL/j8+TOahuw0BOvOI2Nz616hPaxVcEJ/4bACALSuJFESXsUucAwz9qVU2nJzsN7yzFpKJ+b9iet8D68uhEU/XHC5nHE4kE63684wdkIlFabJII+VEo6Erwue1yguv+cBQOLnCq1dAJfLSECJNHhzTHmX/Q9lcT6mvkoR5Z2cj17cVnbY/HT3Gb9/+d3zuVJqWjwisBjr/G1Zv5u3SwthyV4WFlBsI0q6ROn0fgZLCvJWXvStLMK1xXNrXasU1zsuGkdRghQeeESDYeix2z1jv39xJ2mBIhLlXbJXBCKVADSfiBIl9X2OfstP6WJtw9ou6PvqwBrXG7MEMbuQ88UlsHA9SikoSUGrB/5tBowwXqvw+EBswpffvjj3dtrdpUgD+y0pPrMP4fBiDbgAoIN4ESa1lD6CEv6rpDVwxzrLaZqw3+/dSdoR/XBx+csexTnvd4tAtkaBS3ko303dS/rD7zk/G7MLpX7kCy7+zOxEVVWOXaRyqqrC3d0dHh8f8en+wbv1eH46iogT928hmL0yDvy3loXDiRLViB/6lRT3r04p8IjPm6YBl+6E0+mA42mPS3ciF23nmrLGg3LibS+elDUeOBfM1n6nxAcIaVBp70EhMuAhBa1SVbJll9pfaoP/bOHUgFSnEgJNJQFNPmh3m9a7yTPF9c6UkL5+IyjqmpKSeF0eJykWFLeEP076mtTrv1tZGYvvrkzoX5nySV/7nIMHNtgPnE4nXC4XXC4EXMpvnUBGgtQaZV1jGUpb/hoLsVZWqf1+HjJeUS5UYHph3J4vqqttitrPMk5d16g0eQzfbVq07R25w0enaHxSFrc7ZR9SbUMO2itsg0EebZ4Dpa8FZQzBOq8LVu/V//6qlFvN+ckTFPFGOAuycRxxPp+J6jqDbWqdGxe4S7LtsqxbtsESUF6nunFdrMJKQ70RhYsMV7xfXLWIvCiEgFLVYueJtRwhYL6bGQcTtj+oROWDjmw2GzQVeVNopakdjuL6w5zIfoFUZjJQXLkEbgnAcbrZkyIZyBWd8K2qsV+d1ijt6u8i8IdsUshG3KTXDKpxEuxSalWiDDkv6Z+1wVA9N1gvTVD8W059S1tqrEm4RnE5T9wu/sx8v7Bl3lS5sjd648FbVRW0DIuk9GJLI+HAC7u+0EsAzlMC3tBY3obSDi0GNs22GPDXvssnWLzS2NfSmxeMsYCxEO60jGIvDP7+BFIDTYE9EJZusDE84fkgr8d34PZd431LgF8Da1qfSQAZVFt1AuIAbpWAJlB+BjMdfXOEVvbiZRsEcpjUaDR5d9SanCiVIu2FgoSQMYh1Al4vGAMQ8v3zreMBj8GYswzXqEMp3xrgrz3z1ufyMq49xb/HdbnbG6CsAoT1/G7Xn3G5nDGOvfdyXQPe6sK+QQBaeybOt1Z+TDlZ+o8pbgzkJTXUq8Ii1adJOFOO0oo0CB65JTXQTntQKQ42wnxFeilgqe9Uz88dQ2nmn6hweBtc6walBAoZbaFxMq4QFvKSJ0sTvPKbzT4F6TlNC8EsL99y2azDVUA0SQYCUiv/3DTPOJz2OB4pZGd/6aBkOHE0czhJM3OJyqd2u+Q9S9J5DEID4SPYEG/JbIlwZfDYzgvqGIM2N1+MWYYcrLIAKK+yMnR4EBMovplSKYVKpi5IHAjPHzRAOt2sShaPUtoblyOq07eTF537FwtsybyvLF69+EGkxg/X0hoVWQobNCnve3+9vutti7b3jLLRC54PHcYOl8sZ5/MRXX92fbB+Qa7VH/p6TX223vacNQh1LfsfT26gvCnLwODIKXDRngDwFNOX44S+WoV4DLwIEpNJm7MqqR7ZZkJYTolvSdfGXMNdRAfHezD/6h8qPMs/xRb1ecEp//oe0Mbl8inTsp4QUiEHinWUXzjwzRAATCRwGTODfdSMmdFfOlxOZ3SXC6Zh9OD1fSEyGlqVHd/GqqS4vX57TiVaaroNEc2FTdkNrjs24YtHhkHmwSFkeEm6zyz/PgYRGRct7/9lSl0zD5tpKmThZCyn8EKQvUJcX2nhXCOAcZ4Sq6bZJx/CQECR85uV4LtoLM24/xtS+O9z3rhUiZ+UQnkSIvn+V70jNk3EDGuEfzd2crxuj667uAOJKQygm1wI128pqP0AKqWz+mS6BEWgaH5MRA5QNxkWi+/CUX1pxxDJ3zG19QKbjIQ0Rf0QisKRwoVPKp2+MU9cyZRy+7qRsi2h/pTCM+XNwevbjbQPOdsQj10JW/p03LsMzltVkDlbDtr4PQfdWgo8Vbmc0velxfGh4LVkzkjOguSxy+qxy/mMeZyghERT1RSJRlDUACPIo2KGTd6tFJDWsY2z8H9bGQY9TjF4Y2CWwbsUEHO2IQdvDJ4YfFYKaKEBJSnskpKomDJnbEVOWeOySwuHtRd5PiPSxeaftenBxRpP+xqLoZ+fn4pITz9zYJL0nUGQgp71g+nv1/4mCpWX/9YUnl8GlgPYdJG/lzZsP/M8Y8KMqe8gpcTdpkFbV7QbifQkKi43H2Cbua1YaxMQJ2Xw4sqE3lw7AQDCWL94jIBfTMJQ+Qpi8Z5TS1aRJSBdCeIsRcYD3wjeBW/rwJsLlii4s8eUNx6LawDW5+NhFbx+EFfIGkmZ9LeRFspKGGkhTfjdwqw+bw3830Jm9WQTWkpJx/JyF5kzRbwNgeqMMb7qbbOBaGp3ehU5V2b8bCz9x9/FW2AcUzZPDMa8f6nKynr5wbCqD47nFcL/LYVIvvexvZCCClIttv98O8/1wEVQuj7lbupw/bbuXWbPe4orRXFMXks5AdB2Np68lzK7IXUCQ/puMQcBewZmGAhLymeyCb7hcs3o+eVvNxoBrV/f6n9PyjEBiJ7SWZq4WlTuVnQKaByfQvEzSdWFv3miTcF1O3+uxP/6thoLrFyCUmpTTKk8WDLwXqOwoe3l+yAWO00hxkIp79rvi4OaRQ+vJ125m11eG9zS76Xf3rKibn1+Ld9a28Kk5vEknWuO4nyB2lB+FukpZqww5b7E8SjyXSueKBWxP0KIq/KBtXbJmwsLbmwM4NXJz3YC3jks855IBanSth+r32Clp6bxS7gtQ4olOJMx4cWTC2bcH0+whbeljscj7mNC8d13uq7r1QG9BpC1/G9JC95uhaq9pQ1p2dHOAcCD15evkm06uPQwL16mmGvBrVcnsZAn7xexGjH1VK7dy5BRr9UTvlevgpfylfW/pe+pnWa1DclijtSdOdXm/pbGZY2A5d//H3pUcqyxKRwwAAAAAElFTkSuQmCC
"""

struct HFBotanicalBranch: View {
    var body: some View {
        Group {
            if let data = Data(base64Encoded: hfReferenceBranchBase64),
               let image = UIImage(data: data) {
                Image(uiImage: image)
                    .resizable()
                    .interpolation(.high)
                    .scaledToFit()
            }
        }
        .allowsHitTesting(false)
    }
}

struct HFPageBackground<Content: View>: View {
    let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            hfBackground
                .ignoresSafeArea()

            content

            HFBotanicalBranch()
                .frame(width: 190, height: 270)
                .offset(x: 4, y: 8)
        }
    }
}

struct HFEditingTask: Identifiable {
    let id = UUID()
    let text: String
}

struct TodayView: View {
    var body: some View { HFTaskListView(scope: .today) }
}

struct WeekView: View {
    var body: some View { HFTaskListView(scope: .week) }
}

struct MonthView: View {
    var body: some View { HFTaskListView(scope: .month) }
}

struct HFTaskListView: View {
    let scope: HFTaskScope

    @State private var tasks: [String]
    @State private var completed: Set<String>
    @State private var reminders: [String: Date]
    @State private var showAdd = false
    @State private var editingTask: HFEditingTask?

    init(scope: HFTaskScope) {
        self.scope = scope
        _tasks = State(initialValue: storedArray(scope.tasksKey))
        _completed = State(initialValue: Set(storedArray(scope.completedKey)))
        _reminders = State(initialValue: loadReminderData(scope.reminderKey))
    }

    var body: some View {
        HFPageBackground {
            VStack(spacing: 0) {
                HFDateHeader(scope: scope)

                ScrollView(showsIndicators: false) {
                    LazyVStack(spacing: 0) {
                        if tasks.isEmpty {
                            HStack {
                                Text("Zatiaľ tu nič nie je.")
                                    .font(.system(size: 15))
                                    .foregroundStyle(hfMuted)
                                Spacer()
                            }
                            .padding(.horizontal, 22)
                            .padding(.vertical, 22)
                        } else {
                            ForEach(tasks, id: \.self) { task in
                                HFReferenceTaskRow(
                                    text: task,
                                    completed: completed.contains(task),
                                    reminder: reminders[task],
                                    onToggle: { toggle(task) },
                                    onEdit: { editingTask = HFEditingTask(text: task) }
                                )
                                .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                                    Button(role: .destructive) {
                                        delete(task)
                                    } label: {
                                        Label("Zmazať", systemImage: "trash")
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(minLength: 0)

                Button {
                    showAdd = true
                } label: {
                    Image(systemName: "plus")
                        .font(.system(size: 28, weight: .light))
                        .foregroundStyle(Color.white)
                        .frame(width: 66, height: 66)
                        .background(hfGreen, in: Circle())
                        .shadow(color: Color.black.opacity(0.10), radius: 5, y: 2)
                }
                .padding(.bottom, 24)
            }
        }
        .navigationTitle(scope.title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(hfBackground, for: .navigationBar)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button { showAdd = true } label: {
                    Image(systemName: "ellipsis")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(hfText)
                        .frame(width: 40, height: 40)
                        .background(hfGold.opacity(0.16), in: Circle())
                }
            }
        }
        .sheet(isPresented: $showAdd) {
            HFAddTaskView { text, date in
                add(text, reminder: date)
            }
        }
        .sheet(item: $editingTask) { selectedTask in
            HFEditTaskView(
                originalTask: selectedTask.text,
                reminder: reminders[selectedTask.text]
            ) { newText, newReminder in
                editTask(
                    oldTask: selectedTask.text,
                    rawNewTask: newText,
                    newReminder: newReminder
                )
            }
        }
    }

    private func persist() {
        UserDefaults.standard.set(tasks, forKey: scope.tasksKey)
        UserDefaults.standard.set(Array(completed), forKey: scope.completedKey)
        saveReminderData(reminders, key: scope.reminderKey)
    }

    private func add(_ raw: String, reminder: Date?) {
        let text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, !tasks.contains(text) else { return }

        tasks.append(text)

        if let reminder {
            reminders[text] = reminder
            if reminder > Date() {
                scheduleReminder(task: text, date: reminder, scope: scope.notificationScope)
            }
        }

        persist()
    }

    private func toggle(_ task: String) {
        if completed.contains(task) {
            completed.remove(task)
        } else {
            completed.insert(task)
            cancelReminder(task: task, scope: scope.notificationScope)
        }
        persist()
    }

    private func delete(_ task: String) {
        tasks.removeAll { $0 == task }
        completed.remove(task)
        reminders.removeValue(forKey: task)
        cancelReminder(task: task, scope: scope.notificationScope)
        persist()
    }

    private func editTask(oldTask: String, rawNewTask: String, newReminder: Date?) {
        let newTask = rawNewTask.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !newTask.isEmpty else { return }

        if oldTask != newTask {
            if let index = tasks.firstIndex(of: oldTask) {
                tasks[index] = newTask
            }

            if completed.contains(oldTask) {
                completed.remove(oldTask)
                completed.insert(newTask)
            }

            if reminders[oldTask] != nil {
                reminders.removeValue(forKey: oldTask)
                cancelReminder(task: oldTask, scope: scope.notificationScope)
            }

            if let newReminder {
                reminders[newTask] = newReminder
            }
        } else {
            cancelReminder(task: oldTask, scope: scope.notificationScope)
            reminders.removeValue(forKey: oldTask)

            if let newReminder {
                reminders[oldTask] = newReminder
            }
        }

        cancelReminder(task: newTask, scope: scope.notificationScope)

        if !completed.contains(newTask),
           let reminder = reminders[newTask],
           reminder > Date() {
            scheduleReminder(task: newTask, date: reminder, scope: scope.notificationScope)
        }

        persist()
    }
}

struct HFDateHeader: View {
    let scope: HFTaskScope

    var body: some View {
        HStack(spacing: 13) {
            ZStack {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(hfGold.opacity(0.16))
                    .frame(width: 52, height: 52)

                Image(systemName: {
                    switch scope {
                    case .today: return "sun.max"
                    case .week, .month: return "calendar"
                    }
                }())
                    .font(.system(size: 25, weight: .light))
                    .foregroundStyle(hfGold)
            }

            VStack(alignment: .leading, spacing: 3) {
                switch scope {
                case .today:
                    Text(Date(), format: .dateTime.weekday(.abbreviated).day().month(.wide))
                        .font(.system(size: 16, weight: .medium))
                    Text("Tvoje dnešné veci")
                        .font(.system(size: 12))
                        .foregroundStyle(hfMuted)
                case .week, .month:
                    Text(scope.title)
                        .font(.system(size: 16, weight: .medium))
                }
            }
            .foregroundStyle(hfText)

            Spacer()
        }
        .padding(.horizontal, 20)
        .padding(.top, 12)
        .padding(.bottom, 12)
        .overlay(alignment: .bottom) {
            Rectangle()
                .fill(hfLine)
                .frame(height: 1)
        }
    }
}

struct HFReferenceTaskRow: View {
    let text: String
    let completed: Bool
    let reminder: Date?
    let onToggle: () -> Void
    let onEdit: () -> Void

    var body: some View {
        Button(action: onEdit) {
            HStack(spacing: 13) {
                Button(action: onToggle) {
                    Image(systemName: completed ? "checkmark.circle.fill" : "circle")
                        .font(.system(size: 29, weight: .light))
                        .foregroundStyle(completed ? hfGreen : Color(red: 0.60, green: 0.58, blue: 0.47))
                }
                .buttonStyle(.plain)

                VStack(alignment: .leading, spacing: 3) {
                    Text(text)
                        .font(.system(size: 16, weight: .regular))
                        .foregroundStyle(completed ? hfMuted : hfText)
                        .strikethrough(completed)

                    if let reminder {
                        Text(reminder, style: .time)
                            .font(.system(size: 13))
                            .foregroundStyle(hfMuted)
                    }
                }

                Spacer(minLength: 8)

                Image(systemName: "chevron.right")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(hfMuted.opacity(0.72))
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 17)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .overlay(alignment: .bottom) {
            Rectangle()
                .fill(hfLine)
                .frame(height: 1)
                .padding(.leading, 72)
        }
    }
}

struct HFAddTaskView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var text = ""
    @State private var reminderEnabled = false
    @State private var date = Date().addingTimeInterval(3600)

    let onSave: (String, Date?) -> Void

    var body: some View {
        NavigationStack {
            HFPageBackground {
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 0) {
                        HStack {
                            Text("Čo potrebuješ vybaviť?")
                                .font(.system(size: 14))
                                .foregroundStyle(hfMuted)
                            Spacer()
                        }
                        .padding(20)

                        HFPlainInput(title: "Úloha", text: $text, placeholder: "Napíš úlohu…")

                        HStack {
                            Image(systemName: "bell")
                                .foregroundStyle(hfGreen)
                            Text("Pripomienka")
                                .foregroundStyle(hfText)
                            Spacer()
                            Toggle("", isOn: $reminderEnabled)
                                .labelsHidden()
                                .tint(hfGreen)
                        }
                        .padding(20)
                        .overlay(alignment: .bottom) {
                            Rectangle().fill(hfLine).frame(height: 1)
                        }

                        if reminderEnabled {
                            DatePicker("Kedy?", selection: $date, displayedComponents: [.date, .hourAndMinute])
                                .padding(20)
                                .tint(hfGreen)
                                .overlay(alignment: .bottom) {
                                    Rectangle().fill(hfLine).frame(height: 1)
                                }
                        }
                    }
                }
            }
            .navigationTitle("Nová úloha")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(hfBackground, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Zrušiť") { dismiss() }
                        .foregroundStyle(hfText)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Uložiť") {
                        onSave(text, reminderEnabled ? date : nil)
                        dismiss()
                    }
                    .foregroundStyle(hfGreen)
                    .font(.system(size: 15, weight: .semibold))
                    .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
    }
}

struct HFPlainInput: View {
    let title: String
    @Binding var text: String
    let placeholder: String

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(title.uppercased())
                .font(.system(size: 10, weight: .bold))
                .foregroundStyle(hfMuted)

            TextField(placeholder, text: $text)
                .font(.system(size: 16))
                .foregroundStyle(hfText)
        }
        .padding(20)
        .overlay(alignment: .bottom) {
            Rectangle().fill(hfLine).frame(height: 1)
        }
    }
}

struct HFEditTaskView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var text: String
    @State private var reminderEnabled: Bool
    @State private var date: Date

    let originalTask: String
    let reminder: Date?
    let onSave: (String, Date?) -> Void

    init(originalTask: String, reminder: Date?, onSave: @escaping (String, Date?) -> Void) {
        self.originalTask = originalTask
        self.reminder = reminder
        self.onSave = onSave
        _text = State(initialValue: originalTask)
        _reminderEnabled = State(initialValue: reminder != nil)
        _date = State(initialValue: reminder ?? Date().addingTimeInterval(3600))
    }

    var body: some View {
        NavigationStack {
            HFPageBackground {
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 0) {
                        HFPlainInput(title: "Úloha", text: $text, placeholder: "Čo treba urobiť?")

                        HStack {
                            Image(systemName: "calendar")
                                .foregroundStyle(hfGreen)
                            Text("Dátum")
                                .foregroundStyle(hfText)
                            Spacer()
                        }
                        .padding(20)
                        .overlay(alignment: .bottom) {
                            Rectangle().fill(hfLine).frame(height: 1)
                        }

                        HStack {
                            Image(systemName: "bell")
                                .foregroundStyle(hfGreen)
                            Text("Pripomienka")
                                .foregroundStyle(hfText)
                            Spacer()
                            Toggle("", isOn: $reminderEnabled)
                                .labelsHidden()
                                .tint(hfGreen)
                        }
                        .padding(20)
                        .overlay(alignment: .bottom) {
                            Rectangle().fill(hfLine).frame(height: 1)
                        }

                        if reminderEnabled {
                            DatePicker("Kedy?", selection: $date, displayedComponents: [.date, .hourAndMinute])
                                .padding(20)
                                .tint(hfGreen)
                                .overlay(alignment: .bottom) {
                                    Rectangle().fill(hfLine).frame(height: 1)
                                }
                        }
                    }
                }
            }
            .navigationTitle("Upraviť úlohu")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(hfBackground, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Zrušiť") { dismiss() }
                        .foregroundStyle(hfText)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Uložiť") {
                        onSave(text, reminderEnabled ? date : nil)
                        dismiss()
                    }
                    .foregroundStyle(hfGreen)
                    .font(.system(size: 15, weight: .semibold))
                    .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
    }
}

// MARK: - IDEAS

struct IdeasView: View {
    @State private var ideas: [String] = storedArray("ideas")
    @State private var showAdd = false

    var body: some View {
        HFPageBackground {
            ScrollView(showsIndicators: false) {
                LazyVStack(spacing: 0) {
                    ForEach(ideas, id: \.self) { idea in
                        HStack(spacing: 13) {
                            Image(systemName: "lightbulb")
                                .foregroundStyle(hfGold)
                            Text(idea)
                                .font(.system(size: 16))
                                .foregroundStyle(hfText)
                            Spacer()
                            Image(systemName: "chevron.right")
                                .font(.system(size: 13))
                                .foregroundStyle(hfMuted)
                        }
                        .padding(20)
                        .overlay(alignment: .bottom) {
                            Rectangle().fill(hfLine).frame(height: 1)
                        }
                        .swipeActions(allowsFullSwipe: true) {
                            Button(role: .destructive) {
                                ideas.removeAll { $0 == idea }
                                UserDefaults.standard.set(ideas, forKey: "ideas")
                            } label: {
                                Label("Zmazať", systemImage: "trash")
                            }
                        }
                    }
                }
            }
        }
        .navigationTitle("Nápady")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(hfBackground, for: .navigationBar)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button { showAdd = true } label: {
                    Image(systemName: "plus")
                        .foregroundStyle(hfText)
                        .frame(width: 40, height: 40)
                        .background(hfGold.opacity(0.16), in: Circle())
                }
            }
        }
        .sheet(isPresented: $showAdd) {
            HFTextAddView(title: "Nový nápad", placeholder: "Napíš nápad…") { value in
                let text = value.trimmingCharacters(in: .whitespacesAndNewlines)
                guard !text.isEmpty else { return }
                ideas.append(text)
                UserDefaults.standard.set(ideas, forKey: "ideas")
            }
        }
    }
}

// MARK: - SHOPPING

struct ShoppingView: View {
    @State private var items: [String] = storedArray("shoppingItems")
    @State private var completed: Set<String> = Set(storedArray("completedShoppingItems"))
    @State private var showAdd = false

    var body: some View {
        HFPageBackground {
            ScrollView(showsIndicators: false) {
                LazyVStack(spacing: 0) {
                    ForEach(items, id: \.self) { item in
                        HStack(spacing: 13) {
                            Button {
                                if completed.contains(item) { completed.remove(item) }
                                else { completed.insert(item) }
                                UserDefaults.standard.set(Array(completed), forKey: "completedShoppingItems")
                            } label: {
                                Image(systemName: completed.contains(item) ? "checkmark.circle.fill" : "circle")
                                    .font(.system(size: 29, weight: .light))
                                    .foregroundStyle(completed.contains(item) ? hfGreen : Color(red: 0.60, green: 0.58, blue: 0.47))
                            }
                            .buttonStyle(.plain)

                            Text(item)
                                .font(.system(size: 16))
                                .foregroundStyle(completed.contains(item) ? hfMuted : hfText)
                                .strikethrough(completed.contains(item))

                            Spacer()
                            Image(systemName: "chevron.right")
                                .font(.system(size: 13))
                                .foregroundStyle(hfMuted)
                        }
                        .padding(20)
                        .overlay(alignment: .bottom) {
                            Rectangle().fill(hfLine).frame(height: 1).padding(.leading, 72)
                        }
                        .swipeActions(allowsFullSwipe: true) {
                            Button(role: .destructive) {
                                items.removeAll { $0 == item }
                                completed.remove(item)
                                UserDefaults.standard.set(items, forKey: "shoppingItems")
                                UserDefaults.standard.set(Array(completed), forKey: "completedShoppingItems")
                            } label: {
                                Label("Zmazať", systemImage: "trash")
                            }
                        }
                    }
                }
            }
        }
        .navigationTitle("Nákupy")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(hfBackground, for: .navigationBar)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button { showAdd = true } label: {
                    Image(systemName: "plus")
                        .foregroundStyle(hfText)
                        .frame(width: 40, height: 40)
                        .background(hfGold.opacity(0.16), in: Circle())
                }
            }
        }
        .sheet(isPresented: $showAdd) {
            HFTextAddView(title: "Nový nákup", placeholder: "Čo treba kúpiť?") { value in
                let text = value.trimmingCharacters(in: .whitespacesAndNewlines)
                guard !text.isEmpty else { return }
                items.append(text)
                UserDefaults.standard.set(items, forKey: "shoppingItems")
            }
        }
    }
}

// MARK: - EXPENSES

struct ExpensesView: View {
    @State private var expenses: [String] = storedArray("plannedExpenses")
    @State private var showAdd = false

    var body: some View {
        HFPageBackground {
            ScrollView(showsIndicators: false) {
                LazyVStack(spacing: 0) {
                    ForEach(expenses, id: \.self) { expense in
                        HStack(spacing: 13) {
                            Image(systemName: "eurosign.circle")
                                .foregroundStyle(hfGold)
                            Text(expense)
                                .font(.system(size: 16))
                                .foregroundStyle(hfText)
                            Spacer()
                            Image(systemName: "chevron.right")
                                .font(.system(size: 13))
                                .foregroundStyle(hfMuted)
                        }
                        .padding(20)
                        .overlay(alignment: .bottom) {
                            Rectangle().fill(hfLine).frame(height: 1)
                        }
                        .swipeActions(allowsFullSwipe: true) {
                            Button(role: .destructive) {
                                expenses.removeAll { $0 == expense }
                                UserDefaults.standard.set(expenses, forKey: "plannedExpenses")
                            } label: {
                                Label("Zmazať", systemImage: "trash")
                            }
                        }
                    }
                }
            }
        }
        .navigationTitle("Plánované výdavky")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(hfBackground, for: .navigationBar)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button { showAdd = true } label: {
                    Image(systemName: "plus")
                        .foregroundStyle(hfText)
                        .frame(width: 40, height: 40)
                        .background(hfGold.opacity(0.16), in: Circle())
                }
            }
        }
        .sheet(isPresented: $showAdd) {
            HFTextAddView(title: "Nový výdavok", placeholder: "Čo plánuješ kúpiť alebo zaplatiť?") { value in
                let text = value.trimmingCharacters(in: .whitespacesAndNewlines)
                guard !text.isEmpty else { return }
                expenses.append(text)
                UserDefaults.standard.set(expenses, forKey: "plannedExpenses")
            }
        }
    }
}

// MARK: - SIMPLE ADD

struct HFTextAddView: View {
    @Environment(\.dismiss) private var dismiss
    let title: String
    let placeholder: String
    let onSave: (String) -> Void
    @State private var text = ""

    var body: some View {
        NavigationStack {
            HFPageBackground {
                VStack(alignment: .leading, spacing: 0) {
                    HFPlainInput(title: "Text", text: $text, placeholder: placeholder)
                    Spacer()
                }
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(hfBackground, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Zrušiť") { dismiss() }
                        .foregroundStyle(hfText)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Uložiť") {
                        onSave(text)
                        dismiss()
                    }
                    .foregroundStyle(hfGreen)
                    .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
    }
}

// MARK: - REMINDERS

struct HFRemindersView: View {
    private var reminders: [(String, Date)] {
        var result: [(String, Date)] = []
        for scope in [HFTaskScope.today, .week, .month] {
            let tasks = storedArray(scope.tasksKey)
            let current = loadReminderData(scope.reminderKey)
            for task in tasks {
                if let date = current[task], date > Date() {
                    result.append((task, date))
                }
            }
        }
        return result.sorted { $0.1 < $1.1 }
    }

    var body: some View {
        HFPageBackground {
            ScrollView(showsIndicators: false) {
                LazyVStack(spacing: 0) {
                    ForEach(Array(reminders.enumerated()), id: \.offset) { _, item in
                        HStack(spacing: 13) {
                            Image(systemName: "bell")
                                .foregroundStyle(hfGreen)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(item.0)
                                    .font(.system(size: 16))
                                    .foregroundStyle(hfText)
                                Text(item.1, style: .date)
                                    .font(.system(size: 13))
                                    .foregroundStyle(hfMuted)
                            }
                            Spacer()
                            Text(item.1, style: .time)
                                .font(.system(size: 13))
                                .foregroundStyle(hfMuted)
                            Image(systemName: "chevron.right")
                                .font(.system(size: 13))
                                .foregroundStyle(hfMuted)
                        }
                        .padding(20)
                        .overlay(alignment: .bottom) {
                            Rectangle().fill(hfLine).frame(height: 1).padding(.leading, 54)
                        }
                    }
                }
            }
        }
        .navigationTitle("Pripomienky")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(hfBackground, for: .navigationBar)
    }
}

// MARK: - SETTINGS

struct HFSettingsView: View {
    @AppStorage("headFreeIntroSeen") private var introSeen = true

    var body: some View {
        HFPageBackground {
            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {
                    Button {
                        introSeen = false
                    } label: {
                        HStack(spacing: 13) {
                            Image(systemName: "arrow.counterclockwise")
                                .foregroundStyle(hfGreen)
                            Text("Zobraziť úvod znova")
                                .foregroundStyle(hfText)
                            Spacer()
                            Image(systemName: "chevron.right")
                                .font(.system(size: 13))
                                .foregroundStyle(hfMuted)
                        }
                        .padding(20)
                    }
                    .buttonStyle(.plain)
                    .overlay(alignment: .bottom) {
                        Rectangle().fill(hfLine).frame(height: 1)
                    }
                }
            }
        }
        .navigationTitle("Nastavenia")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(hfBackground, for: .navigationBar)
    }
}

// MARK: - ADD MENU

struct AddMenuView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            HFPageBackground {
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 0) {
                        HFAddMenuRow(title: "Úloha", icon: "checkmark.circle")
                        HFAddMenuRow(title: "Nápad", icon: "lightbulb")
                        HFAddMenuRow(title: "Nákup", icon: "cart")
                        HFAddMenuRow(title: "Výdavok", icon: "eurosign.circle")
                    }
                }
            }
            .navigationTitle("Čo chceš pridať?")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(hfBackground, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Zrušiť") { dismiss() }
                        .foregroundStyle(hfText)
                }
            }
        }
    }
}

struct HFAddMenuRow: View {
    let title: String
    let icon: String

    @ViewBuilder
    private var destination: some View {
        switch title {
        case "Úloha":
            TodayView()
        case "Nápad":
            IdeasView()
        case "Nákup":
            ShoppingView()
        default:
            ExpensesView()
        }
    }

    var body: some View {
        NavigationLink(destination: destination) {
            HStack(spacing: 13) {
                Image(systemName: icon)
                    .foregroundStyle(hfGreen)
                    .frame(width: 28)
                Text(title)
                    .font(.system(size: 16))
                    .foregroundStyle(hfText)
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.system(size: 13))
                    .foregroundStyle(hfMuted)
            }
            .padding(20)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .overlay(alignment: .bottom) {
            Rectangle().fill(hfLine).frame(height: 1)
        }
    }
}
