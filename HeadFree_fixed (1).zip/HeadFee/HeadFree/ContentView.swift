import SwiftUI
import Foundation
import UserNotifications

struct ContentView: View {

    @State private var showAddMenu = false

    var body: some View {

        NavigationStack {

            List {

                NavigationLink {

                    TodayView()

                } label: {

                    MenuRow(icon: "checkmark.circle", title: "Dnes")

                }

                NavigationLink {

                    WeekView()

                } label: {

                    MenuRow(icon: "calendar", title: "Tento týždeň")

                }

                NavigationLink {

                    MonthView()

                } label: {

                    MenuRow(icon: "calendar.badge.clock", title: "Tento mesiac")

                }

                NavigationLink {

                    IdeasView()

                } label: {

                    MenuRow(icon: "lightbulb", title: "Nápady")

                }

                NavigationLink {

                    ShoppingView()

                } label: {

                    MenuRow(icon: "cart", title: "Nákupy")

                }

                NavigationLink {

                    ExpensesView()

                } label: {

                    MenuRow(icon: "eurosign.circle", title: "Plánované výdavky")

                }

            }

            .navigationTitle("HeadFree")
            .listStyle(.insetGrouped)

            .toolbar {

                ToolbarItem(placement: .topBarTrailing) {

                    Button {

                        showAddMenu = true

                    } label: {

                        Image(systemName: "plus")

                    }

                }

            }

            .sheet(isPresented: $showAddMenu) {

                AddMenuView()

            }

        }

    }

}


// MARK: - SPOLOČNÉ +

struct AddMenuView: View {

    @Environment(\.dismiss) private var dismiss

    var body: some View {

        NavigationStack {

            List {

                NavigationLink {

                    TodayView()

                } label: {

                    Label("Úloha", systemImage: "checkmark.circle")

                }

                NavigationLink {

                    IdeasView()

                } label: {

                    Label("Nápad", systemImage: "lightbulb")

                }

                NavigationLink {

                    ShoppingView()

                } label: {

                    Label("Nákup", systemImage: "cart")

                }

                NavigationLink {

                    ExpensesView()

                } label: {

                    Label("Výdavok", systemImage: "eurosign.circle")

                }

            }

            .navigationTitle("Čo chceš pridať?")

            .toolbar {

                ToolbarItem(placement: .cancellationAction) {

                    Button("Zrušiť") {

                        dismiss()

                    }

                }

            }

        }

    }

}


// MARK: - PRIPOMIENKY

private func loadReminders(_ stored: String) -> [String: Date] {

    guard !stored.isEmpty,
          let data = stored.data(using: .utf8),
          let reminders = try? JSONDecoder().decode(
            [String: Date].self,
            from: data
          )
    else {

        return [:]

    }

    return reminders

}

private func saveReminders(_ reminders: [String: Date]) -> String {

    guard let data = try? JSONEncoder().encode(reminders),
          let string = String(data: data, encoding: .utf8)
    else {

        return ""

    }

    return string

}


// MARK: - SKUTOČNÉ NOTIFIKÁCIE

private func reminderIdentifier(
    _ task: String,
    scope: String
) -> String {

    let encoded = Data(task.utf8).base64EncodedString()

    return "HeadFree.\(scope).\(encoded)"

}

private func scheduleReminder(
    for task: String,
    at date: Date,
    scope: String
) {

    guard date > Date() else {
        print("HEADFREE REMINDER REJECTED: DATE IS IN THE PAST")
        return
    }

    let center = UNUserNotificationCenter.current()

    center.getNotificationSettings { settings in

        print("HEADFREE AUTH STATUS:", settings.authorizationStatus.rawValue)
        print("HEADFREE ALERT:", settings.alertSetting.rawValue)
        print("HEADFREE SOUND:", settings.soundSetting.rawValue)

        guard settings.authorizationStatus == .authorized ||
              settings.authorizationStatus == .provisional ||
              settings.authorizationStatus == .ephemeral else {

            print("HEADFREE REMINDER NOT SCHEDULED: NOT AUTHORIZED")
            return
        }

        let content = UNMutableNotificationContent()

        content.title = "HeadFree"
        content.body = task
        content.sound = .default

        let components = Calendar.current.dateComponents(
            [.year, .month, .day, .hour, .minute],
            from: date
        )

        print("HEADFREE REMINDER DATE:", date)
        print("HEADFREE REMINDER COMPONENTS:", components)

        let trigger = UNTimeIntervalNotificationTrigger(
            timeInterval: 10,
            repeats: false
        )

        let request = UNNotificationRequest(
            identifier: reminderIdentifier(
                task,
                scope: scope
            ),
            content: content,
            trigger: trigger
        )

        center.add(request) { error in

            if let error = error {

                print("HEADFREE REMINDER ADD ERROR:", error)

            } else {

                print("HEADFREE REMINDER ADDED OK")

            }

            center.getPendingNotificationRequests { requests in

                print("HEADFREE PENDING REMINDERS:", requests.count)

                for pending in requests {

                    print(
                        "HEADFREE PENDING:",
                        pending.identifier
                    )

                }

            }

        }

    }

}

private func cancelReminder(
    for task: String,
    scope: String
) {

    UNUserNotificationCenter.current()
        .removePendingNotificationRequests(
            withIdentifiers: [
                reminderIdentifier(
                    task,
                    scope: scope
                )
            ]
        )

}


// MARK: - DNES

struct TodayView: View {

    @AppStorage("todayTasks")
    private var savedTasks = ""

    @AppStorage("completedTodayTasks")
    private var savedCompletedTasks = ""

    @AppStorage("todayTaskReminders")
    private var savedReminders = ""

    @State private var showAddTask = false

    private var tasks: [String] {

        savedTasks.isEmpty
        ? []
        : savedTasks.components(separatedBy: "|||")

    }

    private var completedTasks: Set<String> {

        Set(
            savedCompletedTasks.isEmpty
            ? []
            : savedCompletedTasks.components(
                separatedBy: "|||"
            )
        )

    }

    private var reminders: [String: Date] {

        loadReminders(savedReminders)

    }

    var body: some View {

        List {

            if tasks.isEmpty {

                ContentUnavailableView(
                    "Zatiaľ tu nič nemáš.",
                    systemImage: "checkmark.circle",
                    description: Text("Pridaj prvú úlohu.")
                )

            } else {

                ForEach(tasks, id: \.self) { task in

                    TaskRow(
                        text: task,
                        completed: completedTasks.contains(task),
                        reminder: reminders[task]
                    ) {

                        toggleTask(task)

                    }

                }

                .onDelete { offsets in

                    var updated = tasks
                    var reminderData = reminders

                    for index in offsets.sorted(by: >) {

                        cancelReminder(
                            for: updated[index],
                            scope: "today"
                        )

                        reminderData.removeValue(
                            forKey: updated[index]
                        )

                        updated.remove(at: index)

                    }

                    savedTasks =
                        updated.joined(separator: "|||")

                    savedReminders =
                        saveReminders(reminderData)

                }

            }

        }

        .navigationTitle("Dnes")

        .toolbar {

            ToolbarItem(
                placement: .topBarTrailing
            ) {

                Button {

                    showAddTask = true

                } label: {

                    Image(systemName: "plus")

                }

            }

        }

        .sheet(isPresented: $showAddTask) {

            AddTaskView { task, reminder in

                addTask(
                    task,
                    reminder: reminder
                )

            }

        }

    }

    private func addTask(
        _ text: String,
        reminder: Date?
    ) {

        let task =
            text.trimmingCharacters(
                in: .whitespacesAndNewlines
            )

        guard !task.isEmpty else {
            return
        }

        var updated = tasks

        updated.append(task)

        savedTasks =
            updated.joined(separator: "|||")

        var reminderData = reminders

        if let reminder {

            reminderData[task] = reminder

            scheduleReminder(
                for: task,
                at: reminder,
                scope: "today"
            )

        } else {

            reminderData.removeValue(
                forKey: task
            )

            cancelReminder(
                for: task,
                scope: "today"
            )

        }

        savedReminders =
            saveReminders(reminderData)

    }

    private func toggleTask(_ task: String) {

        var completed = completedTasks

        if completed.contains(task) {

            completed.remove(task)

            if let reminder = reminders[task] {

                scheduleReminder(
                    for: task,
                    at: reminder,
                    scope: "today"
                )

            }

        } else {

            completed.insert(task)

            cancelReminder(
                for: task,
                scope: "today"
            )

        }

        savedCompletedTasks =
            completed.joined(separator: "|||")

    }

}


// MARK: - TÝŽDEŇ

struct WeekView: View {

    @AppStorage("weekTasks")
    private var savedTasks = ""

    @AppStorage("completedWeekTasks")
    private var savedCompletedTasks = ""

    @AppStorage("weekTaskReminders")
    private var savedReminders = ""

    @State private var showAddTask = false

    private var tasks: [String] {

        savedTasks.isEmpty
        ? []
        : savedTasks.components(separatedBy: "|||")

    }

    private var completedTasks: Set<String> {

        Set(
            savedCompletedTasks.isEmpty
            ? []
            : savedCompletedTasks.components(
                separatedBy: "|||"
            )
        )

    }

    private var reminders: [String: Date] {

        loadReminders(savedReminders)

    }

    var body: some View {

        List {

            if tasks.isEmpty {

                ContentUnavailableView(
                    "Tento týždeň je zatiaľ prázdny.",
                    systemImage: "calendar",
                    description: Text(
                        "Sem si odlož veci, ktoré chceš stihnúť tento týždeň."
                    )
                )

            } else {

                ForEach(tasks, id: \.self) { task in

                    TaskRow(
                        text: task,
                        completed: completedTasks.contains(task),
                        reminder: reminders[task]
                    ) {

                        toggleTask(task)

                    }

                }

                .onDelete { offsets in

                    var updated = tasks
                    var reminderData = reminders

                    for index in offsets.sorted(by: >) {

                        cancelReminder(
                            for: updated[index],
                            scope: "week"
                        )

                        reminderData.removeValue(
                            forKey: updated[index]
                        )

                        updated.remove(at: index)

                    }

                    savedTasks =
                        updated.joined(separator: "|||")

                    savedReminders =
                        saveReminders(reminderData)

                }

            }

        }

        .navigationTitle("Tento týždeň")

        .toolbar {

            ToolbarItem(
                placement: .topBarTrailing
            ) {

                Button {

                    showAddTask = true

                } label: {

                    Image(systemName: "plus")

                }

            }

        }

        .sheet(isPresented: $showAddTask) {

            AddTaskView { task, reminder in

                addTask(
                    task,
                    reminder: reminder
                )

            }

        }

    }

    private func addTask(
        _ text: String,
        reminder: Date?
    ) {

        let task =
            text.trimmingCharacters(
                in: .whitespacesAndNewlines
            )

        guard !task.isEmpty else {
            return
        }

        var updated = tasks

        updated.append(task)

        savedTasks =
            updated.joined(separator: "|||")

        var reminderData = reminders

        if let reminder {

            reminderData[task] = reminder

            scheduleReminder(
                for: task,
                at: reminder,
                scope: "week"
            )

        } else {

            reminderData.removeValue(
                forKey: task
            )

            cancelReminder(
                for: task,
                scope: "week"
            )

        }

        savedReminders =
            saveReminders(reminderData)

    }

    private func toggleTask(_ task: String) {

        var completed = completedTasks

        if completed.contains(task) {

            completed.remove(task)

            if let reminder = reminders[task] {

                scheduleReminder(
                    for: task,
                    at: reminder,
                    scope: "week"
                )

            }

        } else {

            completed.insert(task)

            cancelReminder(
                for: task,
                scope: "week"
            )

        }

        savedCompletedTasks =
            completed.joined(separator: "|||")

    }

}


// MARK: - MESIAC

struct MonthView: View {

    @AppStorage("monthTasks")
    private var savedTasks = ""

    @AppStorage("completedMonthTasks")
    private var savedCompletedTasks = ""

    @AppStorage("monthTaskReminders")
    private var savedReminders = ""

    @State private var showAddTask = false

    private var tasks: [String] {

        savedTasks.isEmpty
        ? []
        : savedTasks.components(separatedBy: "|||")

    }

    private var completedTasks: Set<String> {

        Set(
            savedCompletedTasks.isEmpty
            ? []
            : savedCompletedTasks.components(
                separatedBy: "|||"
            )
        )

    }

    private var reminders: [String: Date] {

        loadReminders(savedReminders)

    }

    var body: some View {

        List {

            if tasks.isEmpty {

                ContentUnavailableView(
                    "Tento mesiac je zatiaľ prázdny.",
                    systemImage: "calendar.badge.clock",
                    description: Text(
                        "Sem si odlož veci, ktoré chceš vybaviť tento mesiac."
                    )
                )

            } else {

                ForEach(tasks, id: \.self) { task in

                    TaskRow(
                        text: task,
                        completed: completedTasks.contains(task),
                        reminder: reminders[task]
                    ) {

                        toggleTask(task)

                    }

                }

                .onDelete { offsets in

                    var updated = tasks
                    var reminderData = reminders

                    for index in offsets.sorted(by: >) {

                        cancelReminder(
                            for: updated[index],
                            scope: "month"
                        )

                        reminderData.removeValue(
                            forKey: updated[index]
                        )

                        updated.remove(at: index)

                    }

                    savedTasks =
                        updated.joined(separator: "|||")

                    savedReminders =
                        saveReminders(reminderData)

                }

            }

        }

        .navigationTitle("Tento mesiac")

        .toolbar {

            ToolbarItem(
                placement: .topBarTrailing
            ) {

                Button {

                    showAddTask = true

                } label: {

                    Image(systemName: "plus")

                }

            }

        }

        .sheet(isPresented: $showAddTask) {

            AddTaskView { task, reminder in

                addTask(
                    task,
                    reminder: reminder
                )

            }

        }

    }

    private func addTask(
        _ text: String,
        reminder: Date?
    ) {

        let task =
            text.trimmingCharacters(
                in: .whitespacesAndNewlines
            )

        guard !task.isEmpty else {
            return
        }

        var updated = tasks

        updated.append(task)

        savedTasks =
            updated.joined(separator: "|||")

        var reminderData = reminders

        if let reminder {

            reminderData[task] = reminder

            scheduleReminder(
                for: task,
                at: reminder,
                scope: "month"
            )

        } else {

            reminderData.removeValue(
                forKey: task
            )

            cancelReminder(
                for: task,
                scope: "month"
            )

        }

        savedReminders =
            saveReminders(reminderData)

    }

    private func toggleTask(_ task: String) {

        var completed = completedTasks

        if completed.contains(task) {

            completed.remove(task)

            if let reminder = reminders[task] {

                scheduleReminder(
                    for: task,
                    at: reminder,
                    scope: "month"
                )

            }

        } else {

            completed.insert(task)

            cancelReminder(
                for: task,
                scope: "month"
            )

        }

        savedCompletedTasks =
            completed.joined(separator: "|||")

    }

}


// MARK: - RIADOK ÚLOHY

struct TaskRow: View {

    let text: String
    let completed: Bool
    let reminder: Date?
    let action: () -> Void

    var body: some View {

        Button {

            action()

        } label: {

            HStack(spacing: 12) {

                Image(
                    systemName: completed
                    ? "checkmark.square.fill"
                    : "square"
                )

                VStack(
                    alignment: .leading,
                    spacing: 3
                ) {

                    Text(text)
                        .strikethrough(completed)
                        .foregroundStyle(
                            completed
                            ? .secondary
                            : .primary
                        )

                    if let reminder {

                        HStack(spacing: 4) {

                            Image(systemName: "bell.fill")

                            Text(
                                reminder,
                                style: .date
                            )

                            Text(
                                reminder,
                                style: .time
                            )

                        }
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    }

                }

                Spacer()

            }

        }
        .buttonStyle(.plain)

    }

}


// MARK: - PRIDAŤ ÚLOHU

struct AddTaskView: View {

    @Environment(\.dismiss)
    private var dismiss

    @State private var text = ""

    @State private var reminderEnabled = false

    @State private var reminderDate =
        Date().addingTimeInterval(3600)

    let onAdd: (String, Date?) -> Void

    var body: some View {

        NavigationStack {

            Form {

                TextField(
                    "Čo treba urobiť?",
                    text: $text
                )

                Toggle(
                    "Pripomenúť",
                    isOn: $reminderEnabled
                )

                if reminderEnabled {

                    DatePicker(
                        "Kedy?",
                        selection: $reminderDate,
                        displayedComponents: [
                            .date,
                            .hourAndMinute
                        ]
                    )

                }

            }

            .navigationTitle("Nová úloha")

            .toolbar {

                ToolbarItem(
                    placement: .cancellationAction
                ) {

                    Button("Zrušiť") {

                        dismiss()

                    }

                }

                ToolbarItem(
                    placement: .confirmationAction
                ) {

                    Button("Pridať") {

                        onAdd(
                            text,
                            reminderEnabled
                            ? reminderDate
                            : nil
                        )

                        dismiss()

                    }
                    .disabled(
                        text.trimmingCharacters(
                            in: .whitespacesAndNewlines
                        ).isEmpty
                    )

                }

            }

        }

    }

}


// MARK: - NÁPADY

struct IdeasView: View {

    @AppStorage("ideas")
    private var savedIdeas = ""

    @State private var newIdea = ""

    @State private var showAddIdea = false

    private var ideas: [String] {

        savedIdeas.isEmpty
        ? []
        : savedIdeas.components(separatedBy: "|||")

    }

    var body: some View {

        List {

            if ideas.isEmpty {

                ContentUnavailableView(
                    "Zatiaľ žiadne nápady.",
                    systemImage: "lightbulb",
                    description: Text(
                        "Sem si môžeš odložiť čokoľvek."
                    )
                )

            } else {

                ForEach(ideas, id: \.self) { idea in

                    Text(idea)

                }

                .onDelete { offsets in

                    var updated = ideas

                    for index in offsets.sorted(by: >) {

                        updated.remove(at: index)

                    }

                    savedIdeas =
                        updated.joined(separator: "|||")

                }

            }

        }

        .navigationTitle("Nápady")

        .toolbar {

            ToolbarItem(
                placement: .topBarTrailing
            ) {

                Button {

                    newIdea = ""
                    showAddIdea = true

                } label: {

                    Image(systemName: "plus")

                }

            }

        }

        .sheet(isPresented: $showAddIdea) {

            NavigationStack {

                Form {

                    TextField(
                        "Napíš nápad…",
                        text: $newIdea
                    )

                }

                .navigationTitle("Nový nápad")

                .toolbar {

                    ToolbarItem(
                        placement: .cancellationAction
                    ) {

                        Button("Zrušiť") {

                            showAddIdea = false

                        }

                    }

                    ToolbarItem(
                        placement: .confirmationAction
                    ) {

                        Button("Pridať") {

                            addIdea()

                        }
                        .disabled(
                            newIdea.trimmingCharacters(
                                in: .whitespacesAndNewlines
                            ).isEmpty
                        )

                    }

                }

            }

        }

    }

    private func addIdea() {

        let idea =
            newIdea.trimmingCharacters(
                in: .whitespacesAndNewlines
            )

        guard !idea.isEmpty else {
            return
        }

        var updated = ideas

        updated.append(idea)

        savedIdeas =
            updated.joined(separator: "|||")

        newIdea = ""
        showAddIdea = false

    }

}


// MARK: - NÁKUPY

struct ShoppingView: View {

    @AppStorage("shoppingItems")
    private var savedItems = ""

    @AppStorage("completedShoppingItems")
    private var savedCompletedItems = ""

    @State private var newItems = ""

    @State private var showAddItems = false

    private var items: [String] {

        savedItems.isEmpty
        ? []
        : savedItems.components(separatedBy: "|||")

    }

    private var completedItems: Set<String> {

        Set(
            savedCompletedItems.isEmpty
            ? []
            : savedCompletedItems.components(
                separatedBy: "|||"
            )
        )

    }

    var body: some View {

        List {

            if items.isEmpty {

                ContentUnavailableView(
                    "Nákupný zoznam je prázdny.",
                    systemImage: "cart",
                    description: Text(
                        "Pridaj veci, ktoré potrebuješ kúpiť."
                    )
                )

            } else {

                ForEach(items, id: \.self) { item in

                    Button {

                        toggleItem(item)

                    } label: {

                        HStack(spacing: 12) {

                            Image(
                                systemName:
                                    completedItems.contains(item)
                                    ? "checkmark.square.fill"
                                    : "square"
                            )

                            Text(item)
                                .strikethrough(
                                    completedItems.contains(item)
                                )
                                .foregroundStyle(
                                    completedItems.contains(item)
                                    ? .secondary
                                    : .primary
                                )

                            Spacer()

                        }

                    }
                    .buttonStyle(.plain)

                }

                .onDelete { offsets in

                    var updated = items

                    for index in offsets.sorted(by: >) {

                        updated.remove(at: index)

                    }

                    savedItems =
                        updated.joined(separator: "|||")

                }

            }

        }

        .navigationTitle("Nákupy")

        .toolbar {

            ToolbarItem(
                placement: .topBarTrailing
            ) {

                Button {

                    newItems = ""
                    showAddItems = true

                } label: {

                    Image(systemName: "plus")

                }

            }

        }

        .sheet(isPresented: $showAddItems) {

            NavigationStack {

                VStack(
                    alignment: .leading,
                    spacing: 8
                ) {

                    Text(
                        "Každú vec napíš na nový riadok."
                    )
                    .foregroundStyle(.secondary)
                    .padding(.horizontal)
                    .padding(.top)

                    TextEditor(text: $newItems)
                        .padding(.horizontal)

                }

                .navigationTitle("Nové nákupy")

                .toolbar {

                    ToolbarItem(
                        placement: .cancellationAction
                    ) {

                        Button("Zrušiť") {

                            showAddItems = false

                        }

                    }

                    ToolbarItem(
                        placement: .confirmationAction
                    ) {

                        Button("Pridať") {

                            addItems()

                        }
                        .disabled(
                            newItems.trimmingCharacters(
                                in: .whitespacesAndNewlines
                            ).isEmpty
                        )

                    }

                }

            }

        }

    }

    private func addItems() {

        let new = newItems
            .components(separatedBy: .newlines)
            .map {

                $0.trimmingCharacters(
                    in: .whitespacesAndNewlines
                )

            }
            .filter {

                !$0.isEmpty

            }

        guard !new.isEmpty else {
            return
        }

        var updated = items

        updated.append(contentsOf: new)

        savedItems =
            updated.joined(separator: "|||")

        newItems = ""
        showAddItems = false

    }

    private func toggleItem(_ item: String) {

        var completed = completedItems

        if completed.contains(item) {

            completed.remove(item)

        } else {

            completed.insert(item)

        }

        savedCompletedItems =
            completed.joined(separator: "|||")

    }

}


// MARK: - PLÁNOVANÉ VÝDAVKY

struct ExpensesView: View {

    @AppStorage("plannedExpenses")
    private var savedExpenses = ""

    @AppStorage("completedPlannedExpenses")
    private var savedCompletedExpenses = ""

    @State private var newExpense = ""

    @State private var showAddExpense = false

    private var expenses: [String] {

        savedExpenses.isEmpty
        ? []
        : savedExpenses.components(separatedBy: "|||")

    }

    private var completedExpenses: Set<String> {

        Set(
            savedCompletedExpenses.isEmpty
            ? []
            : savedCompletedExpenses.components(
                separatedBy: "|||"
            )
        )

    }

    private var totalExpenses: Double {

        expenses.reduce(0) { total, expense in

            if completedExpenses.contains(expense) {

                return total

            }

            return total + extractAmount(
                from: expense
            )

        }

    }

    private func extractAmount(
        from text: String
    ) -> Double {

        let pattern =
            #"([0-9][0-9\s]*)(?:[,.]([0-9]{1,2}))?\s*€"#

        guard
            let regex = try? NSRegularExpression(
                pattern: pattern
            ),
            let match = regex.firstMatch(
                in: text,
                range: NSRange(
                    text.startIndex...,
                    in: text
                )
            )
        else {

            return 0

        }

        guard let wholeRange = Range(
            match.range(at: 1),
            in: text
        )
        else {

            return 0

        }

        var number = String(
            text[wholeRange]
        )
        .replacingOccurrences(
            of: " ",
            with: ""
        )

        if let decimalRange = Range(
            match.range(at: 2),
            in: text
        ) {

            number += "." + text[decimalRange]

        }

        return Double(number) ?? 0

    }

    var body: some View {

        List {

            if expenses.isEmpty {

                ContentUnavailableView(
                    "Zatiaľ žiadne plánované výdavky.",
                    systemImage: "eurosign.circle",
                    description: Text(
                        "Sem si odlož peniaze, ktoré budeš potrebovať."
                    )
                )

            } else {

                ForEach(
                    expenses,
                    id: \.self
                ) { expense in

                    Button {

                        toggleExpense(expense)

                    } label: {

                        HStack(spacing: 12) {

                            Image(
                                systemName:
                                    completedExpenses.contains(
                                        expense
                                    )
                                    ? "checkmark.square.fill"
                                    : "square"
                            )

                            Text(expense)
                                .strikethrough(
                                    completedExpenses.contains(
                                        expense
                                    )
                                )
                                .foregroundStyle(
                                    completedExpenses.contains(
                                        expense
                                    )
                                    ? .secondary
                                    : .primary
                                )

                            Spacer()

                        }

                    }
                    .buttonStyle(.plain)

                }

                .onDelete { offsets in

                    var updated = expenses
                    var completed = completedExpenses

                    for index in offsets.sorted(by: >) {

                        completed.remove(
                            updated[index]
                        )

                        updated.remove(
                            at: index
                        )

                    }

                    savedExpenses =
                        updated.joined(
                            separator: "|||"
                        )

                    savedCompletedExpenses =
                        completed.joined(
                            separator: "|||"
                        )

                }

                HStack {

                    Text("Spolu")
                        .fontWeight(.semibold)

                    Spacer()

                    Text(
                        totalExpenses,
                        format: .currency(
                            code: "EUR"
                        )
                    )
                    .fontWeight(.semibold)

                }

            }

        }

        .navigationTitle(
            "Plánované výdavky"
        )

        .toolbar {

            ToolbarItem(
                placement: .topBarTrailing
            ) {

                Button {

                    newExpense = ""
                    showAddExpense = true

                } label: {

                    Image(
                        systemName: "plus"
                    )

                }

            }

        }

        .sheet(
            isPresented: $showAddExpense
        ) {

            NavigationStack {

                Form {

                    TextField(
                        "Napr. Linoleum – 220 €",
                        text: $newExpense
                    )

                }

                .navigationTitle(
                    "Nový výdavok"
                )

                .toolbar {

                    ToolbarItem(
                        placement: .cancellationAction
                    ) {

                        Button("Zrušiť") {

                            showAddExpense = false

                        }

                    }

                    ToolbarItem(
                        placement: .confirmationAction
                    ) {

                        Button("Pridať") {

                            addExpense()

                        }
                        .disabled(
                            newExpense.trimmingCharacters(
                                in: .whitespacesAndNewlines
                            ).isEmpty
                        )

                    }

                }

            }

        }

    }

    private func addExpense() {

        let expense =
            newExpense.trimmingCharacters(
                in: .whitespacesAndNewlines
            )

        guard !expense.isEmpty else {
            return
        }

        var updated = expenses

        updated.append(expense)

        savedExpenses =
            updated.joined(separator: "|||")

        newExpense = ""
        showAddExpense = false

    }

    private func toggleExpense(
        _ expense: String
    ) {

        var completed =
            completedExpenses

        if completed.contains(expense) {

            completed.remove(expense)

        } else {

            completed.insert(expense)

        }

        savedCompletedExpenses =
            completed.joined(
                separator: "|||"
            )

    }

}


// MARK: - MENU

struct MenuRow: View {

    let icon: String
    let title: String

    var body: some View {

        HStack(spacing: 14) {

            Image(systemName: icon)
                .frame(width: 24)

            Text(title)

            Spacer()

            Image(
                systemName: "chevron.right"
            )
            .font(.caption)
            .foregroundStyle(.tertiary)

        }

    }

}

#Preview {

    ContentView()

}
