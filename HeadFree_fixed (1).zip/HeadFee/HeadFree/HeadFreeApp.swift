//
//  HeadFreeApp.swift
//  HeadFree
//
//  Created by Tereza Takacova on 03/10/2026.
//

import SwiftUI

@main
struct HeadFreeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
