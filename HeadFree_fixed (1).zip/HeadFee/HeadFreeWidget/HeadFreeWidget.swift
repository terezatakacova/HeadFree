import WidgetKit
import SwiftUI

struct HeadFreeEntry: TimelineEntry {
    let date: Date
}

struct HeadFreeProvider: TimelineProvider {
    func placeholder(in context: Context) -> HeadFreeEntry {
        HeadFreeEntry(date: Date())
    }

    func getSnapshot(in context: Context, completion: @escaping (HeadFreeEntry) -> Void) {
        completion(HeadFreeEntry(date: Date()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<HeadFreeEntry>) -> Void) {
        let entry = HeadFreeEntry(date: Date())
        let timeline = Timeline(entries: [entry], policy: .after(Date().addingTimeInterval(3600)))
        completion(timeline)
    }
}

struct HeadFreeWidgetView: View {
    var entry: HeadFreeEntry

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("HeadFree")
                .font(.headline)

            Text("Dnes")
                .font(.subheadline)

            Text("Tento týždeň")
                .font(.subheadline)

            Text("Nápady")
                .font(.subheadline)
        }
        .padding()
    }
}

@main
struct HeadFreeWidget: Widget {
    let kind = "HeadFreeWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(
            kind: kind,
            provider: HeadFreeProvider()
        ) { entry in
            HeadFreeWidgetView(entry: entry)
        }
        .configurationDisplayName("HeadFree")
        .description("Prehľad HeadFree")
        .supportedFamilies([
            .systemSmall,
            .systemMedium
        ])
    }
}
