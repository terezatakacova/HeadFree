//
//  HeadFeeTests.swift
//  HeadFeeTests
//
//  Created by Tereza Takacova on 03/10/2026.
//

import Testing

struct HeadFeeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
